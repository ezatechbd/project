import 'package:flutter/material.dart';
import 'package:photo_view/photo_view.dart';

class PhotoViewPage extends StatelessWidget {
  final String imageUrl;
  const PhotoViewPage({Key key, @required this.imageUrl }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Stack(
        children: [
          Container(
            child: PhotoView(
              imageProvider: NetworkImage(imageUrl),
              loadingBuilder: (a, b, ){
                return Center(child: CircularProgressIndicator());
              },
            ),
          ),
          Positioned(
            bottom: 20,
            left: 5,
            child: IconButton(
              onPressed: () async {
                print('Tapped share!');
                // final imageurl = 'define your image url here';
                // final uri = Uri.parse(imageurl);
                // final response = await http.get(uri);
                // final bytes = response.bodyBytes;
                // final temp = await getTemporaryDirectory();
                // final path = '${temp.path}/image.jpg';
                // File(path).writeAsBytesSync(bytes);
                // await Share.shareFiles([path], text: 'Image Shared');
              },
              icon: Icon(Icons.share, size: 30),
              color: Colors.white,
            ),
          ),
        ],
      ),
    );
  }
}