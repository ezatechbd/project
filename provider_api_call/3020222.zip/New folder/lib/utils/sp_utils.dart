import 'package:shared_preferences/shared_preferences.dart';

class SharedPref {
  /* :::::::::::::::::::::::::::::::: from api response ::::::::::::::::::::::::::::::::::*/
  Future<bool> setApiResponse(String value) async {
    final SharedPreferences prefs = await SharedPreferences.getInstance();
    return prefs.setString('API_RESP', value);
  }
  
  Future<String> getApiResponse() async {
    final SharedPreferences prefs = await SharedPreferences.getInstance();
    return prefs.getString('API_RESP');
  }
}