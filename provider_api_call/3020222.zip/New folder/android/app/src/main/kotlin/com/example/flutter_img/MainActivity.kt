package com.example.flutter_img

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
