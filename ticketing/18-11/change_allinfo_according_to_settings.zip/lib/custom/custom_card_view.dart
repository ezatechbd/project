import 'package:dil_app/config/common_const.dart';
import 'package:dil_app/pages/chart/chart.dart';
import 'package:flutter/material.dart';

class CustomCardView extends StatelessWidget {
  final String date;
  final String status;
  final String priority;
  final String ticketId;
  final String ticketTitle;
  final String projectName;
  final String clientName;
  final String description;
  final String ticketNo;
  final String ticketReqMode;
  const CustomCardView({
    this.date,
    this.status,
    this.priority,
    this.ticketId,
    this.ticketTitle,
    this.projectName,
    this.clientName,
    this.description,
    this.ticketNo,
    this.ticketReqMode,
  });

  @override
  Widget build(BuildContext context) {
    return Stack(
      children: <Widget>[
        Positioned(
          height: 60,
          //top: 20,
          left: 0,
          right: 10,
          child: Card(
            color: Colors.teal[50],
            child: Padding(
              padding: const EdgeInsets.only(
                top: 5.0,
                left: 5.0,
                right: 5.0,
              ),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                crossAxisAlignment: CrossAxisAlignment.start,
                children: <Widget>[
                  Text(
                    ticketReqMode,
                    style: TextStyle(
                      fontWeight: FontWeight.bold,
                      color: Colors.green,
                    ),
                  ),
                  Text(
                    priority,
                    style: TextStyle(
                      fontWeight: FontWeight.bold,
                      color: Colors.red,
                    ),
                  ),
                ],
              ),
            ),
          ),
        ),
        Positioned(
          height: 60,
          top: 110,
          left: 0,
          right: 10,
          child: Card(
            color: Colors.teal[50],
            child: Padding(
              padding: const EdgeInsets.only(
                bottom: 5.0,
                left: 5.0,
                right: 5.0,
              ),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                crossAxisAlignment: CrossAxisAlignment.end,
                children: <Widget>[
                  Text(
                    date,
                    style: TextStyle(
                      fontWeight: FontWeight.bold,
                      color: Colors.blue[600],
                    ),
                  ),
                  Text(
                    status,
                    style: TextStyle(
                      fontWeight: FontWeight.bold,
                      color: Colors.green,
                    ),
                  ),
                ],
              ),
            ),
          ),
        ),
        Positioned(
          bottom: 25,
          left: 5,
          right: 15,
          child: Container(
            height: 170,
            padding: const EdgeInsets.only(top: 50.0),
            child: Card(
              color: Colors.yellow[50],
              elevation: 5.0,
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(5.0),
              ),
              child: Container(
                padding: const EdgeInsets.all(8.0),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: <Widget>[
                    // Text(
                    //   ticketId,
                    //   style: TextStyle(
                    //     fontWeight: FontWeight.bold,
                    //     color: Colors.brown[600],
                    //   ),
                    // ),
                    RichText(
                      text: TextSpan(
                        text: 'Ticket No        : ',
                        style: TextStyle(
                          color: Color(PrimaryColor),
                          fontWeight: FontWeight.bold,
                        ),
                        children: <TextSpan>[
                          TextSpan(
                            text: ticketNo,
                            style: TextStyle(
                              color: Color(PrimaryColor),
                              fontWeight: FontWeight.w400,
                            ),
                          ),
                        ],
                      ),
                    ),
                    RichText(
                      text: TextSpan(
                        text: 'Requested By : ',
                        style: TextStyle(
                          color: Colors.purple[900],
                          fontWeight: FontWeight.bold,
                        ),
                        children: <TextSpan>[
                          TextSpan(
                            text: ChartPage.userName.toString(),
                            style: TextStyle(
                              color: Colors.purple[900],
                              fontWeight: FontWeight.w400,
                            ),
                          ),
                        ],
                      ),
                    ),
                    Text(
                      ticketTitle,
                      style: TextStyle(
                        fontWeight: FontWeight.bold,
                        color: Colors.black,
                      ),
                      overflow: TextOverflow.ellipsis,
                      maxLines: 1,
                    ),
                    Text(
                      projectName,
                      style: TextStyle(
                        fontWeight: FontWeight.bold,
                        color: Colors.green,
                      ),
                      overflow: TextOverflow.ellipsis,
                      maxLines: 1,
                    ),
                    Text(
                      clientName,
                      style: TextStyle(
                        fontWeight: FontWeight.bold,
                        color: Colors.blue,
                      ),
                      overflow: TextOverflow.ellipsis,
                      maxLines: 1,
                    ),
                    // Text(
                    //   description,
                    //   style: TextStyle(color: Colors.grey[600]),
                    //   overflow: TextOverflow.ellipsis,
                    //   maxLines: 2,
                    // ),
                  ],
                ),
              ),
            ),
          ),
        ),
      ],
    );
  }
}
