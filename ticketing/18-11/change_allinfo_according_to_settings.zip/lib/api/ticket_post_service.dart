import 'dart:convert';
import 'dart:async';
import 'dart:developer';
import 'package:dil_app/config/common_const.dart';
import 'package:dil_app/model/ticket_post_model.dart';
import 'package:http/http.dart' as http;

Future<Ticket> createTicket(
    String ticketDescString,
    String ticketTitleString,
    String pROJTNAME,
    String pROJECTID,
    String cLIENTSID,
    String cOMPANYID,
    String tKTPRIID,
    String refctktId,
    String userCode,
    String attachment,
    String ticketPriorityString) async {
  Map data = {
    "clients": {"CLIENTS_ID": cLIENTSID, "COMPANY_ID": cOMPANYID},
    "projects": {"PROJECT_ID": pROJECTID, "PROJT_NAME": pROJTNAME},
    "ticketDescString": ticketDescString,
    "ticketMode": {"TR_MODE_ID": "6"},
    "ticketPriority": {"TKT_PRI_ID": tKTPRIID},
    "ticketTitle": {"refctkt_id": refctktId},
    "ticketTitleString": ticketTitleString,
    "ticketType": {"TR_TYPE_ID": "2"},
    "userCode": userCode,
    "ticketPriorityString": ticketPriorityString,
    "attatchments": [
      {"UserCode": userCode, "Attachment": attachment}
    ]
  };

  var body = json.encode(data);
  String extUrl = 'submitTicketAttachmentEmail';
  Uri url = Uri.parse(baseUrl + extUrl);
  //String url = 'http://192.168.0.89/ati-erp/api/submitTicket';

  final http.Response response = await http.post(url, body: body);
  print(response.body);
  log(body);

  if (response.statusCode == 200) {
    return Ticket.fromJson(
      jsonDecode(response.body),
    );
  } else {
    throw Exception('Failed to submit');
  }
}
