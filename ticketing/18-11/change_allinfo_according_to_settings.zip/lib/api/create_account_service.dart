import 'dart:convert';
import 'dart:async';
import 'dart:developer';
import 'package:dil_app/config/common_const.dart';
import 'package:flutter/cupertino.dart';
import 'package:http/http.dart' as http;

class AccountService {
  Future createAccount({
    @required String userCode,
    @required String clientName,
    @required String clientID,
    @required String projectName,
    @required String projectID,
    @required String name,
    @required String email,
    @required String mobileNo,
    @required String deptName,
    @required String designationName,
  }) async {
    Map data = {
      "userCode": userCode,
      "clientName": clientName,
      "clientID": clientID,
      "projectName": projectName,
      "projectID": projectID,
      "name": name,
      "email": email,
      "mobileNo": mobileNo,
      "deptName": deptName,
      "designationName": designationName,
    };

    var body = json.encode(data);
    String extUrl = 'create_client_user';
    Uri url = Uri.parse(baseUrl + extUrl);
    //String url = 'http://192.168.0.89/ati-erp/api/create_client_user';

    final http.Response response = await http.post(url, body: body);
    print(response.body);
    log(body);

    if (response.statusCode == 200) {
      log(response.body);
      return json.decode(response.body);
    } else {
      throw Exception('Failed to submit');
    }
  }
}
