// import 'dart:convert';
// import 'package:http/http.dart' as http;
// import 'package:ati_ams/config/common_const.dart';
// import 'package:flutter/material.dart';
// import 'package:shared_preferences/shared_preferences.dart';

// class SelectAuthorizedBy extends StatefulWidget {
//   static Map mySelection;
//   const SelectAuthorizedBy({
//     Key key,
//   }) : super(key: key);

//   @override
//   _SelectAuthorizedByState createState() => _SelectAuthorizedByState();
// }

// class _SelectAuthorizedByState extends State<SelectAuthorizedBy> {
//   bool isLoading = true;
//   Map authorizeByDropdown;
//   @override
//   void initState() {
//     dropdownService();
//     SelectAuthorizedBy.mySelection = null;
//     super.initState();
//   }

//   dropdownService() async {
//     // below sp values are set in login
//     SharedPreferences prefs = await SharedPreferences.getInstance();
//     String departmentId = prefs.getString('departmentId').toString();
//     String courseType = prefs.getString('courseType').toString();
//     String courseNameId = prefs.getString('courseNameId').toString();
//     Map data = {
//       "department_id": departmentId,
//       "course_type": courseType,
//       "course_name_id": courseNameId,
//     };
//     var body = json.encode(data);
//     String extUrl = 'get_events';
//     Uri url = Uri.parse(baseUrl + extUrl);
//     // String url = "http://192.168.0.89:8000/birdem-ams/api/get_events";

//     final response = await http.post(
//       url,
//       headers: {"Content-Type": "application/json"},
//       body: body,
//     );

//     if (response.statusCode == 200) {
//       setState(() {
//         isLoading = false;
//         authorizeByDropdown = json.decode(response.body);
//       });
//     } else {
//       // setState(() {
//       //   isLoading = false;
//       // });
//       throw Exception('Failed to load internet');
//     }
//   }

//   @override
//   Widget build(BuildContext context) {
//     return isLoading
//         ? Container()
//         : Row(
//             children: [
//               Icon(
//                 Icons.select_all,
//                 color: Colors.green,
//               ),
//               Container(
//                 height: 30,
//                 // width: 110,
//                 // padding: EdgeInsets.only(left: 5.0),
//                 // decoration: BoxDecoration(
//                 //     border: Border.all(width: 1.5, color: Colors.black),
//                 //     borderRadius: BorderRadius.all(Radius.circular(5))),
//                 child: DropdownButton(
//                   underline: SizedBox(),
//                   // searchHint: 'Select Project',
//                   hint: Padding(
//                     padding: const EdgeInsets.only(left: 8.0),
//                     child: Text(
//                       "Authorized by",
//                       style: TextStyle(
//                         color: Colors.black,
//                         fontSize: 12,
//                       ),
//                     ),
//                   ),
//                   isExpanded: false,
//                   items: authorizeByDropdown['data']['teacher_list']
//                       .map<DropdownMenuItem<Map>>((item) {
//                     return new DropdownMenuItem<Map>(
//                       value: item,
//                       child: Padding(
//                         padding: const EdgeInsets.only(left: 8.0),
//                         child: new Text(
//                           item["name"].toString(),
//                         ),
//                       ),
//                     );
//                   }).toList(),
//                   onChanged: (newVal) {
//                     setState(() {
//                       SelectAuthorizedBy.mySelection =
//                           newVal == null ? {} : newVal;
//                       print(
//                         SelectAuthorizedBy.mySelection.toString(),
//                         // SelectAuthorizedBy.mySelection['PROJT_NAME']
//                         //     .toString(),
//                       );
//                     });
//                   },
//                   // validator: (newVal) => newVal == null ? ' * required' : null,
//                   value: SelectAuthorizedBy.mySelection,
//                 ),
//               ),
//             ],
//           );
//   }
// }
