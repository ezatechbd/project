// To parse this JSON data, do
//
//     final createEventDropdownModel = createEventDropdownModelFromJson(jsonString);

import 'dart:convert';

CreateEventDropdownModel createEventDropdownModelFromJson(String str) =>
    CreateEventDropdownModel.fromJson(json.decode(str));

String createEventDropdownModelToJson(CreateEventDropdownModel data) =>
    json.encode(data.toJson());

class CreateEventDropdownModel {
  CreateEventDropdownModel({
    this.success,
    this.message,
    this.data,
  });

  final bool success;
  final String message;
  final Data data;

  factory CreateEventDropdownModel.fromJson(Map<String, dynamic> json) =>
      CreateEventDropdownModel(
        success: json["success"],
        message: json["message"],
        data: Data.fromJson(json["data"]),
      );

  Map<String, dynamic> toJson() => {
        "success": success,
        "message": message,
        "data": data.toJson(),
      };
}

class Data {
  Data({
    this.topic,
    this.activityInfo,
    this.teacherList,
  });

  final List<Topic> topic;
  final List<dynamic> activityInfo;
  final List<TeacherList> teacherList;

  factory Data.fromJson(Map<String, dynamic> json) => Data(
        topic: List<Topic>.from(json["topic"].map((x) => Topic.fromJson(x))),
        activityInfo: List<dynamic>.from(json["activity_info"].map((x) => x)),
        teacherList: List<TeacherList>.from(
            json["teacher_list"].map((x) => TeacherList.fromJson(x))),
      );

  Map<String, dynamic> toJson() => {
        "topic": List<dynamic>.from(topic.map((x) => x.toJson())),
        "activity_info": List<dynamic>.from(activityInfo.map((x) => x)),
        "teacher_list": List<dynamic>.from(teacherList.map((x) => x.toJson())),
      };
}

class TeacherList {
  TeacherList({
    this.id,
    this.name,
  });

  final int id;
  final String name;

  factory TeacherList.fromJson(Map<String, dynamic> json) => TeacherList(
        id: json["id"],
        name: json["name"],
      );

  Map<String, dynamic> toJson() => {
        "id": id,
        "name": name,
      };
}

class Topic {
  Topic({
    this.id,
    this.courseName,
    this.courseType,
    this.departmentId,
    this.topicId,
    this.topic,
    this.activeStatus,
    this.orgId,
    this.createdBy,
    this.createdAt,
    this.updatedBy,
    this.updatedAt,
  });

  final int id;
  final int courseName;
  final int courseType;
  final int departmentId;
  final int topicId;
  final String topic;
  final int activeStatus;
  final int orgId;
  final dynamic createdBy;
  final DateTime createdAt;
  final dynamic updatedBy;
  final dynamic updatedAt;

  factory Topic.fromJson(Map<String, dynamic> json) => Topic(
        id: json["id"],
        courseName: json["course_name"],
        courseType: json["course_type"],
        departmentId: json["department_id"],
        topicId: json["topic_id"],
        topic: json["topic"],
        activeStatus: json["active_status"],
        orgId: json["org_id"],
        createdBy: json["created_by"],
        createdAt: DateTime.parse(json["created_at"]),
        updatedBy: json["updated_by"],
        updatedAt: json["updated_at"],
      );

  Map<String, dynamic> toJson() => {
        "id": id,
        "course_name": courseName,
        "course_type": courseType,
        "department_id": departmentId,
        "topic_id": topicId,
        "topic": topic,
        "active_status": activeStatus,
        "org_id": orgId,
        "created_by": createdBy,
        "created_at": createdAt.toIso8601String(),
        "updated_by": updatedBy,
        "updated_at": updatedAt,
      };
}
