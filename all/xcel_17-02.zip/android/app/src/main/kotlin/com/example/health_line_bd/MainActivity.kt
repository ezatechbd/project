package com.example.health_line_bd

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
