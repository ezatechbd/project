import 'dart:convert';
import 'dart:developer';
import 'package:health_line_bd/config/common_const.dart';
import 'package:http/http.dart' as http;

class AppointmentRequestService {
  // static int statusCode;
  Future sendRequest(Map data) async {
    var body = json.encode(data);
    String extUrl = 'pat-consult/appointment/req/save';
    Uri url = Uri.parse(baseUrl + extUrl);
    // String url = "https://bdhealthline.net/health-line-bd-ws/api/pat-consult/appointment/req/save";

    final response = await http.post(
      url,
      headers: {"Content-Type": "application/json"},
      body: body,
    );
    print(body);
    // statusCode = response.statusCode;
    if (response.statusCode == 200) {
      log(response.body);
      return jsonDecode(response.body);
    } else {
      log(response.body);
      print("Unable to perform request!");
      return jsonDecode(response.body);
    }
  }
}
