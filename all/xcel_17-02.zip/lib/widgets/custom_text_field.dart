import 'package:flutter/material.dart';
import 'package:health_line_bd/config/common_const.dart';

class CustomtextField extends StatelessWidget {
  const CustomtextField({
    Key key,
    @required this.nameController,
    @required this.labeltext,
    this.readOnly = false,
    this.horizontalPadding = 0.0,
  }) : super(key: key);

  final TextEditingController nameController;
  final String labeltext;
  final bool readOnly;
  final double horizontalPadding;

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.only(top: 10.0),
      child: Container(
        height: 50,
        padding: EdgeInsets.symmetric(horizontal: horizontalPadding),
        child: TextFormField(
          controller: nameController,
          onFieldSubmitted: (String value) {
            nameController.text = value;
          },
          readOnly: readOnly,
          validator: (value) => value.isEmpty ? '* required' : null,
          decoration: InputDecoration(
            enabledBorder: OutlineInputBorder(
              borderSide: BorderSide(width: 1, color: primaryColor),
            ),
            border: OutlineInputBorder(),
            labelText: '$labeltext',
          ),
        ),
      ),
    );
  }
}
