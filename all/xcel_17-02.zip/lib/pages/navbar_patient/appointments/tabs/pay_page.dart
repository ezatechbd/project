import 'package:flutter/material.dart';
import 'package:health_line_bd/config/common_const.dart';
import 'package:health_line_bd/pages/navbar_patient/appointments/components/pay_tile.dart';
import 'package:health_line_bd/pages/navbar_patient/doctors/components/appointment/dialog/consultation_fee_dialog.dart';

class PayPage extends StatelessWidget {
  const PayPage({Key key }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: kBackgroundColor,
      body: ListView.builder(
        itemCount: 10,
        padding: const EdgeInsets.all(10.0),
        itemBuilder: (context, index){
          return PayTile(
            appointmentDate: 'Thursday, March 17, 2022',
            doctorName: 'Doctor Name',
            patientName: 'Patient Name',
            serviceName: 'Service Name',
            consultationFee: 'Consultation Fee',
            onTapPay: (){
              showDialog(
                context: context,
                builder: (context){
                  return ConsultationFeeDialog(
                    doctorName: 'Dr. Sirazul Haque',
                    patientName: 'MD. Enamul Haque',
                    consultationDate: 'Thursday, February 17, 2022',
                    consultationFee: 'GHC 220.00',
                    consultationTime: '10:30 PM',
                  );
                },
              );
            },
          );
        }),
    );
  }
}

