import 'package:flutter/material.dart';
import 'package:health_line_bd/config/common_const.dart';
import 'package:health_line_bd/pages/navbar_patient/appointments/components/upcoming_tile.dart';

class UpcomingPage extends StatelessWidget {
  const UpcomingPage({Key key }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: kBackgroundColor,
      body: ListView.builder(
        itemCount: 10,
        padding: const EdgeInsets.all(8),
        itemBuilder: (context, index){
          return UpcomingTile(
            appointmentDate: 'Thursday, March 17, 2022 11:00 PM',
            doctorName: 'Doctor Name',
            patientName: 'Patient Name',
            designation: 'Designation',
            consultation: 'Consultation',
            onTapVideo: (){},
          );
        }
      ),
    );
  }
}