// import 'package:flutter/material.dart';

// class AppointmentPage extends StatefulWidget {
//   const AppointmentPage({Key key}) : super(key: key);

//   @override
//   _AppointmentPageState createState() => _AppointmentPageState();
// }

// class _AppointmentPageState extends State<AppointmentPage> {
//   TabController _controller;
//   List<String> categories = ["a", "b", "c"];

//   @override
//   void initState() {
//     super.initState();
//   }

//   @override
//   Widget build(BuildContext context) {
//     return DefaultTabController(
//       length: categories.length,
//       child: new Scaffold(
//         appBar: new AppBar(
//           toolbarHeight: 50,
//           brightness: Brightness.dark,
//           bottom: new TabBar(
//             // isScrollable: true,
//             tabs: List<Widget>.generate(categories.length, (int index) {
//                 print(categories[0]);
//                 return new Tab(text: categories[index]);
//               },
//             ),
//           ),
//         ),
//         body: new TabBarView(
//           controller: _controller,
//           children: List<Widget>.generate(categories.length, (int index) {
//               print(categories[0]);
//               return new Text("again some random text");
//             },
//           ),
//         ),
//       ),
//     );
//   }
// }

import 'package:flutter/material.dart';
import 'package:health_line_bd/pages/navbar_patient/appointments/tabs/pay_page.dart';
import 'package:health_line_bd/pages/navbar_patient/appointments/tabs/upcoming_page.dart';

class AppointmentPage extends StatelessWidget {
  const AppointmentPage({Key key }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return DefaultTabController(
        length: 2,
        child: Scaffold(
          appBar: AppBar(
            brightness: Brightness.dark,
            toolbarHeight: 50,
            bottom: const TabBar(
              tabs: [
                Tab(text: 'Upcoming'),
                Tab(text: 'Pay'),
              ],
            ),
          ),
          body: const TabBarView(
            children: [
              UpcomingPage(),
              PayPage(),
            ],
          ),
        ),
      );
  }
}