import 'package:flutter/material.dart';
import 'package:health_line_bd/config/common_const.dart';

class PayTile extends StatelessWidget {
  final String appointmentDate;
  final String doctorName;
  final String patientName;
  final String serviceName;
  final String consultationFee;
  final VoidCallback onTapPay;
  const PayTile({
    Key key,
    @required this.appointmentDate,
    @required this.doctorName,
    @required this.patientName,
    @required this.serviceName,
    @required this.consultationFee,
    @required this.onTapPay,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Container(
      width: double.infinity,
      child: Card(
        elevation: 0.0,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
        child: Padding(
          padding: const EdgeInsets.all(10.0),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Text(
                    appointmentDate,
                    style: TextStyle(fontSize: 15, fontWeight: FontWeight.bold, color: primaryColor),
                  ),
                  ElevatedButton(
                    onPressed: () {
                      onTapPay();
                    },
                    style: ButtonStyle(backgroundColor: MaterialStateProperty.all(cRed)),
                    child: Text('Pay'),
                  ),
                ],
              ),
              Text(doctorName, style: TextStyle(fontSize: 15, color: Colors.grey)),
              SizedBox(height: 5),
              Text(patientName, style: TextStyle(fontSize: 15, color: Colors.grey)),
              SizedBox(height: 5),
              Text(serviceName, style: TextStyle(fontSize: 15, color: Colors.grey)),
              SizedBox(height: 5),
              Text(consultationFee, style: TextStyle(fontSize: 15, color: Colors.grey)),
            ],
          ),
        ),
      ),
    );
  }
}