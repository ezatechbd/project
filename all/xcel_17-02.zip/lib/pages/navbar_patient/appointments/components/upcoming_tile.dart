import 'package:flutter/material.dart';
import 'package:health_line_bd/config/common_const.dart';

class UpcomingTile extends StatelessWidget {
  final String appointmentDate;
  final String doctorName;
  final String patientName;
  final String designation;
  final String consultation;
  final VoidCallback onTapVideo;
  const UpcomingTile({
    Key key,
    @required this.appointmentDate,
    @required this.doctorName,
    @required this.patientName,
    @required this.designation,
    @required this.consultation,
    @required this.onTapVideo,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    var size = MediaQuery.of(context).size;
    return Container(
      width: size.width,
      child: Card(
        elevation: 0.0,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
        child: Padding(
          padding: const EdgeInsets.all(10.0),
          child: Row(
            children: [
              Container(
                height: 80,
                width: 80,
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  border: Border.all(color: primaryColor, width: 5),
                ),
                child: Center(
                  child: Text('1', style: TextStyle(fontSize: 30, fontWeight: FontWeight.bold, color: primaryColor)),
                ),
              ),
              SizedBox(width: 16),
              Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Container(
                    color: primaryColor.withOpacity(0.1),
                    padding: EdgeInsets.symmetric(horizontal: 8),
                    child: Row(
                      children: [
                        Container(
                          width: size.width - 204,
                          child: Text(
                            appointmentDate,
                            style: TextStyle(fontWeight: FontWeight.bold, color: primaryColor),
                          ),
                        ),
                        IconButton(
                          icon: Icon(Icons.videocam, color: primaryColor, size: 30),
                          onPressed: (){
                            onTapVideo();
                          },
                        )
                      ],
                    ),
                  ),
                  SizedBox(height: 5),
                  Text(doctorName, style: TextStyle(fontSize: 15, color: Colors.grey)),
                  SizedBox(height: 5),
                  Text(patientName, style: TextStyle(fontSize: 15, color: Colors.grey)),
                  SizedBox(height: 5),
                  Text(designation, style: TextStyle(fontSize: 15, color: Colors.grey)),
                  SizedBox(height: 5),
                  Text(consultation, style: TextStyle(fontSize: 15, color: Colors.grey)),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }
}