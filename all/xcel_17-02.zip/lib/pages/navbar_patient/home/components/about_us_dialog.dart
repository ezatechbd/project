import 'package:flutter/material.dart';
import 'package:health_line_bd/config/common_const.dart';

class AboutUsDialog extends StatefulWidget {
  const AboutUsDialog({
    Key key,
  }) : super(key: key);

  @override
  _AboutUsDialogState createState() => _AboutUsDialogState();
}

class _AboutUsDialogState extends State<AboutUsDialog> {
  bool isChecked = false;
  @override
  Widget build(BuildContext context) {
    // set up the buttons
    Widget cancelButton = TextButton(
      child: Text("OK"),
      onPressed: () {
        Navigator.pop(context);
      },
    );
    return AlertDialog(
      title: Text("About US"),
      content: SingleChildScrollView(
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              "Welcome to Xcel Medical Centre!",
            ),
            Padding(
              padding: const EdgeInsets.symmetric(vertical: 8.0),
              child: Text(
                'HISTORY',
                style: TextStyle(
                  fontSize: 16,
                  color: primaryColor,
                  fontWeight: FontWeight.bold,
                ),
              ),
            ),
            Text(
              'The glorious journey of ATI Limited started in 1998, established as a software development house, which is now one of the biggest software firms in the country.\nThe focus of the company is to incorporate Advanced Level Computer Education & Training with an intention to make the company instrumental in reducing the existing wide gap between huge demand and very low supply of the IT Professionals by creating skilled manpower in the IT field of the country.',
            ),
            Padding(
              padding: const EdgeInsets.symmetric(vertical: 8.0),
              child: Text(
                'MISSION',
                style: TextStyle(
                  fontSize: 16,
                  color: primaryColor,
                  fontWeight: FontWeight.bold,
                ),
              ),
            ),
            Text(
              'Our mission is to enhance the business growth of our customers with creative Design and Development to deliver market-defining high-quality solutions that create value and reliable competitive advantage for our clients around the world. We ensure in providing end-to-end solution to our clients.\nWe also emphasize to deliver optimal solutions with quality and services at reasonable prices. For us, customer satisfaction is given highest priority. We maintain a cordial relationship with our customers in order to retain existing clients and expand customer circle.',
            ),
            Padding(
              padding: const EdgeInsets.symmetric(vertical: 8.0),
              child: Text(
                'VISION',
                style: TextStyle(
                  fontSize: 16,
                  color: primaryColor,
                  fontWeight: FontWeight.bold,
                ),
              ),
            ),
            Text(
              'Our vision is to develop in a constant manner and grow as a major IT service provider to become a leading performer, in providing quality Web and Software Development solutions in the competitive global marketplace. Our professional, flexible and integrated process reflects in what we do. We invariably try to improve the quality of our products by exploring innovative ideas.',
            ),
          ],
        ),
      ),
      actions: [
        cancelButton,
      ],
    );
  }
}