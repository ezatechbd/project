import 'dart:convert';
import 'package:cool_alert/cool_alert.dart';
import 'package:flutter/material.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:health_line_bd/config/common_const.dart';
import 'package:health_line_bd/config/sp_utils.dart';
import 'package:health_line_bd/pages/login/components/registration_dialog.dart';
import 'package:health_line_bd/pages/login/patient/patient_login_page_hlbd.dart';
import 'package:health_line_bd/pages/navbar_patient/bottom_navbar_patient.dart';
import 'package:health_line_bd/pages/navbar_patient/home/components/about_us_dialog.dart';
import 'package:health_line_bd/pages/navbar_patient/home/components/contact_us_dialog.dart';
import 'package:health_line_bd/pages/navbar_patient/home/components/legal_dialog.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'custom_side_menu.dart';
import 'package:flutter_share/flutter_share.dart';
import 'package:store_redirect/store_redirect.dart';

class DrawerMenu extends StatefulWidget {
  @override
  _DrawerMenuState createState() => _DrawerMenuState();
}

class _DrawerMenuState extends State<DrawerMenu> {
  bool isLoading = true;
  Map loginResp;
  String defaultImageUrl = 'https://raw.githubusercontent.com/ezatechbd/data/master/img/male.png';
  Future getRespFromSP() async {
    var resp = await SharedPref().getPatientLoginResp();
    setState(() {
      loginResp = jsonDecode(resp);
    });
  }

  @override
  void initState() {
    getRespFromSP().then((value) {
      setState(() {
        isLoading = false;
      });
    });
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      // width: (MediaQuery.of(context).size.width) * 0.65,
      width: 250,
      child: Drawer(
        child: ListView(
          padding: EdgeInsets.zero,
          children: <Widget>[
            SizedBox(
              height: 200,
              child: DrawerHeader(
                decoration: BoxDecoration(
                  gradient: LinearGradient(colors: <Color>[cViolet, Colors.blue]),
                ),
                child: SingleChildScrollView(
                  child: isLoading
                    ? Container()
                    : Container(
                    child: Column(
                      children: <Widget>[
                        CircleAvatar(
                          backgroundColor: Colors.green,
                          radius: 50,
                          backgroundImage: NetworkImage( loginResp['listResponse'][0]['imgPath'] ?? defaultImageUrl),
                        ),
                        SizedBox(
                          height: 10,
                        ),
                        Column(
                          children: [
                            Text(
                              loginResp['listResponse'][0]['patientName'] ?? 'Not found',
                              style: TextStyle(color: Colors.white, fontSize: 16),
                            ),
                            Text(
                              loginResp['listResponse'][0]['mobileNo'] ?? 'Not found',
                              style: TextStyle(color: Colors.white, fontSize: 16),
                            ),
                          ],
                        ),
                      ],
                    ),
                  ),
                ),
              ),
            ),
            CustomListTile(
              icon: Icons.home,
              text: 'Dashboard',
              onTap: () {
                Navigator.pushAndRemoveUntil(
                  context,
                  MaterialPageRoute(builder: (context) => BottomNavBarPatient()),
                  (route) => false,
                );
              },
            ),
            CustomListTile(
              icon: Icons.people_alt,
              text: 'Create Patients',
              onTap: () {
                showDialog(
                  context: context,
                  builder: (BuildContext context) {
                    return RegistrationDialog();
                  },
                );
              },
            ),
            CustomListTile(
              icon: Icons.phone,
              text: 'Contact Us',
              onTap: () {
                showDialog(
                  context: context,
                  builder: (BuildContext context) {
                    return ContactUsDialog();
                  },
                );
              },
            ),
            CustomListTile(
              icon: Icons.info,
              text: 'About Us',
              onTap: () {
                showDialog(
                  context: context,
                  builder: (BuildContext context) {
                    return AboutUsDialog();
                  },
                );
              },
            ),
            CustomListTile(
              icon: Icons.privacy_tip,
              text: 'Legal',
              onTap: () {
                showDialog(
                  context: context,
                  builder: (BuildContext context) {
                    return LegalDialog();
                  },
                );
              },
            ),
            CustomListTile(
              icon: Icons.star,
              text: 'Rate Us',
              onTap: () {
                StoreRedirect.redirect(androidAppId: "com.ati.snm");
              },
            ),
            CustomListTile(
              icon: Icons.share,
              text: 'Share App',
              onTap: () async {
                await FlutterShare.share(
                  title: 'Share Xcel Medical Centre',
                  text: 'Share Xcel Medical Centre with your friends and family',
                  linkUrl: 'https://play.google.com/store/apps/details?id=com.ati.snm',
                  chooserTitle: 'Share Xcel Medical Centre',
                );
              },
            ),
            CustomListTile(
              icon: FontAwesomeIcons.signOutAlt,
              text: 'Logout',
              onTap: () {
                CoolAlert.show(
                    context: context,
                    type: CoolAlertType.warning,
                    text: 'Do you want to logout?',
                    showCancelBtn: true,
                    onConfirmBtnTap: () async {
                      SharedPreferences prefs = await SharedPreferences.getInstance();
                      prefs.remove('email');
                      prefs.remove('saveUser');
                      Navigator.of(context, rootNavigator: true).pop();
                      Navigator.pushReplacement(
                        context,
                        MaterialPageRoute(
                          builder: (BuildContext ctx) => PatientLoginPageHLBD(),
                        ),
                      );
                    });
              },
            ),
          ],
        ),
      ),
    );
  }
}
