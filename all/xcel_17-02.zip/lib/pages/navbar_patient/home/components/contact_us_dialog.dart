import 'package:flutter/material.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:health_line_bd/config/common_const.dart';
import 'package:health_line_bd/widgets/custom_button.dart';
import 'package:url_launcher/url_launcher.dart';

class ContactUsDialog extends StatelessWidget {
  const ContactUsDialog({
    Key key,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Dialog(
      shape: RoundedRectangleBorder(borderRadius:BorderRadius.circular(20.0)), //this right here
      child: Container(
        height: 288,
        width: double.infinity,
        child: Column(
          // mainAxisAlignment: MainAxisAlignment.center,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Container(
              height: 70,
              width: double.infinity,
              decoration: BoxDecoration(
                color: primaryColor,
                borderRadius: BorderRadius.only(topLeft: Radius.circular(20), topRight: Radius.circular(20))
              ),
              child: Center(child: Text('Contact Us', style: TextStyle(fontSize: 22, fontWeight: FontWeight.bold, color: Colors.white))),
            ),
            Container(
              height: 208,
              padding: const EdgeInsets.only(left: 24.0),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                mainAxisAlignment: MainAxisAlignment.spaceAround,
                children: [
                  SizedBox(height: 3),
                  Row(
                    children: [
                      CustomIconButton(
                        iconData: FontAwesomeIcons.phone,
                        btnBackgroundColor: Colors.grey[600],
                        btnSize: 24,
                        onBtnTap: () async {
                          const url = "tel: +8801919408812";
                          if (await canLaunch(url)) {
                            await launch(url);
                          } else {
                            throw 'Could not launch $url';
                          }
                        },
                      ),
                      Padding(
                        padding: const EdgeInsets.only(left: 32.0),
                        child: Text('+880 1919408812', style: TextStyle(fontSize: 16, color: Colors.grey[600])),
                      ),
                    ],
                  ),
                   Row(
                     children: [
                      CustomIconButton(
                       iconData: FontAwesomeIcons.whatsapp,
                       btnBackgroundColor: primaryColor,
                       onBtnTap: () async {
                         const url = "whatsapp://send?phone=+8801919408812";
                         if (await canLaunch(url)) {
                          await launch(url);
                         } else {
                           throw 'Could not launch $url';
                         }
                       },
                      ),
                      Padding(
                        padding: const EdgeInsets.only(left: 32.0),
                        child: Text('+880 1919408812', style: TextStyle(fontSize: 16, color: Colors.grey[600])),
                      ),
                     ],
                   ),
                  Row(
                    children: [
                      CustomIconButton(
                        iconData: FontAwesomeIcons.facebookF,
                        btnBackgroundColor: Colors.blue[600],
                        btnSize: 24,
                        onBtnTap: () async {
                          const url = "fb://facewebmodal/f?href=https://www.facebook.com/flutterBangladeshDeveloperCommunity";
                          if (await canLaunch(url)) {
                            await launch(url);
                          } else {
                            throw 'Could not launch $url';
                          }
                        },
                      ),
                      Container(
                        width: MediaQuery.of(context).size.width - 200,
                        height: 40,
                        padding: const EdgeInsets.only(left: 32.0),
                        child: Text(
                          'facebook.com/xcel-medical-centre',
                          overflow: TextOverflow.ellipsis,
                          maxLines: 2,
                          style: TextStyle(fontSize: 16, color: Colors.blue, decoration: TextDecoration.underline),
                        ),
                      ),
                    ],
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}
