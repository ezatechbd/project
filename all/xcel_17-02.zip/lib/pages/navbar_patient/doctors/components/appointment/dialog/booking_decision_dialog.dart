import 'dart:convert';
import 'dart:ui';
import 'package:cool_alert/cool_alert.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:health_line_bd/config/common_const.dart';
import 'package:health_line_bd/config/sp_utils.dart';
import 'package:health_line_bd/model/chamber_model.dart';
import 'package:health_line_bd/model/doctor_category_model.dart';
import 'package:health_line_bd/pages/navbar_patient/doctors/components/appointment/dialog/booking_req_success_dialog.dart';
import 'package:health_line_bd/services/appointment_req_service.dart';

class BookingDecisionDialog extends StatefulWidget {
  final String drName, schedule, imageUrl, appointmentDate, consultationFee;
  final int consultType;
  final DoctorList drInfo;
  final DoctorChamberModel chamberInfo;

  const BookingDecisionDialog({
    Key key,
    @required this.drName,
    @required this.schedule,
    @required this.imageUrl,
    @required this.consultType,
    @required this.drInfo,
    @required this.chamberInfo,
    @required this.appointmentDate,
    @required this.consultationFee,
  }) : super(key: key);

  @override
  _BookingDecisionDialogState createState() => _BookingDecisionDialogState();
}

class _BookingDecisionDialogState extends State<BookingDecisionDialog> {
  Map loginResp;
  bool isLoading = true;
  String patientName = '';
  String patientNo = '';
  Future getRespFromSP() async {
    var resp = await SharedPref().getPatientLoginResp();
    setState(() {
      loginResp = jsonDecode(resp);
    });
  }
  @override
  void initState() {
    getRespFromSP().then((value) {
      setState(() {
        isLoading = false;
      });
    });
    super.initState();
  }
  @override
  Widget build(BuildContext context) {
    patientName = isLoading ? '' : loginResp['listResponse'][0]['patientName'].toString();
    patientNo = isLoading ? '' : loginResp['listResponse'][0]['patientNo'].toString();
    return Dialog(
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(Constants.padding),
      ),
      elevation: 0,
      backgroundColor: Colors.transparent,
      child: contentBox(context),
    );
  }

  contentBox(context) {
    return Stack(
      children: <Widget>[
        Container(
          padding: EdgeInsets.only(
            left: Constants.padding,
            top: Constants.avatarRadius + Constants.padding,
            right: Constants.padding,
            bottom: Constants.padding,
          ),
          margin: EdgeInsets.only(top: Constants.avatarRadius),
          decoration: BoxDecoration(
            shape: BoxShape.rectangle,
            color: Colors.white,
            borderRadius: BorderRadius.circular(Constants.padding),
            boxShadow: [BoxShadow(color: Colors.black, offset: Offset(0, 10), blurRadius: 10)]),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: <Widget>[
              Text(
                widget.drName,
                style: TextStyle(fontSize: 22, fontWeight: FontWeight.w600),
              ),
              SizedBox(height: 8),
              Text(
                widget.schedule,
                style: TextStyle(
                  fontSize: 14,
                  // color: Colors.grey,
                ),
                textAlign: TextAlign.center,
              ),
              SizedBox(height: 8),
              Text(
                'Patient Name: $patientName',
                style: TextStyle(
                  fontSize: 14,
                  // color: Colors.grey,
                ),
                textAlign: TextAlign.center,
              ),
              SizedBox(height: 8),
              Text(
                'Are you sure to book appointment?',
                style: TextStyle(
                  fontSize: 16,
                  color: primaryColor,
                  fontWeight: FontWeight.w500,
                ),
                textAlign: TextAlign.center,
              ),
              SizedBox(height: 22),
              SizedBox(
                width: double.infinity,
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    ElevatedButton(
                      child: Text("  Book  ", style: TextStyle(fontSize: 14)),
                      style: ButtonStyle(
                        backgroundColor: MaterialStateProperty.all(primaryColor),
                        shape: MaterialStateProperty.all<RoundedRectangleBorder>(
                            RoundedRectangleBorder(borderRadius: BorderRadius.circular(18.0)))),
                      onPressed: () {
                        int isFree;
                        int isPaid;
                        if (widget.consultType == 3) {
                          //"widget.consultType" will be replaced with price. 
                          //if price == 0.0, then it will be considered as free
                          isFree = 1; 
                          isPaid = 1; 
                        } else {
                          isFree = 0;
                          isPaid = 0;
                        }
                        Map data = {
                          "chamberNo": widget.drInfo.currentChember,
                          "consultDate": widget.appointmentDate,
                          "consultMedia": widget.chamberInfo.objResponse.consultMediaNo,
                          "consultTypeNo": widget.consultType,
                          "departmentNo": widget.drInfo.departmentNo,
                          "doctorName": widget.drInfo.doctorName,
                          "doctorNo": widget.drInfo.doctorNo,
                          "enterdBy": widget.chamberInfo.objResponse.enteredBy,
                          "isFree": isFree,
                          "isPaid": isPaid,
                          "patientName": patientName,
                          "patientNo": patientNo,
                          "payExpiry": widget.chamberInfo.objResponse.payExpiry,
                          "payMethod": widget.chamberInfo.objResponse.payMethod,
                          "reqStatus": 1,
                          "reqType": 0
                        };
                        showDialog(context: context, builder: (context) => Center(child: CircularProgressIndicator()));
                        AppointmentRequestService().sendRequest(data).then((value) {
                          if (value['statusCode'] == 200) {
                            Navigator.of(context).pop();
                            Navigator.of(context).pop();
                            CoolAlert.show(
                              context: context,
                              type: CoolAlertType.success,
                              text: value['message'],
                            );
                          } else {
                            Navigator.of(context).pop();
                            Navigator.of(context).pop();
                            CoolAlert.show(
                              context: context,
                              type: CoolAlertType.error,
                              text: value['message'],
                            );
                          }
                        });
                      },
                    ),
                    SizedBox(width: 20),
                    ElevatedButton(
                      child: Text("Cancel", style: TextStyle(fontSize: 14)),
                      style: ButtonStyle(
                        backgroundColor: MaterialStateProperty.all(Colors.red),
                        shape: MaterialStateProperty.all<RoundedRectangleBorder>(
                            RoundedRectangleBorder(borderRadius: BorderRadius.circular(18.0)))),
                      onPressed: () {
                        // Navigator.of(context).pop();
                        showDialog(
                          context: context,
                          builder: (context){
                            return BookingReqSuccessDialog(
                              doctorName: widget.drInfo.doctorName,
                              patientName: patientName,
                              consultationDate: widget.appointmentDate,
                              status: 'Not Paid',
                              consultationFee: widget.consultationFee,
                            );
                          },
                        );
                      },
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
        Positioned(
          left: Constants.padding,
          right: Constants.padding,
          child: CircleAvatar(
            backgroundColor: Colors.transparent,
            radius: Constants.avatarRadius,
            child: widget.imageUrl == 'null'
                ? ClipOval(
                    child: Image.asset(
                      defaultFemaleAssetImg,
                      height: 100,
                      width: 100,
                      fit: BoxFit.cover,
                    ),
                  )
                : ClipOval(
                    child: Image.network(
                      widget.imageUrl,
                      height: 100,
                      width: 100,
                      fit: BoxFit.cover,
                    ),
                  ),
          ),
        ),
      ],
    );
  }
}

class Constants {
  Constants._();
  static const double padding = 20;
  static const double avatarRadius = 45;
}
