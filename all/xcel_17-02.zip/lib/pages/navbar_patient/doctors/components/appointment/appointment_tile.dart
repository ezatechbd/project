import 'package:flutter/material.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:health_line_bd/config/common_const.dart';
import 'package:health_line_bd/model/chamber_model.dart';
import 'package:health_line_bd/model/doctor_category_model.dart';
import 'package:intl/intl.dart';
import 'booking_tile.dart';
import 'dialog/booking_decision_dialog.dart';

class AppointmentTile extends StatefulWidget {
  final DoctorChamberModel chamberData;
  final String imageUrl;
  final String drName;
  final DoctorList drInfo;
  const AppointmentTile({
    Key key,
    @required this.chamberData,
    @required this.imageUrl,
    @required this.drName,
    @required this.drInfo,
  }) : super(key: key);

  @override
  _AppointmentTileState createState() => _AppointmentTileState();
}

class _AppointmentTileState extends State<AppointmentTile> {
  String schedule = 'select schedule';
  List<int> sanitizeDate(DoctorChamberModel chamberData) {
    List<int> dayValue = [];
    List<int> dayIndex = [];
    dayValue.add(chamberData.objResponse.sun);
    dayValue.add(chamberData.objResponse.mon);
    dayValue.add(chamberData.objResponse.tue);
    dayValue.add(chamberData.objResponse.wed);
    dayValue.add(chamberData.objResponse.thu);
    dayValue.add(chamberData.objResponse.fri);
    dayValue.add(chamberData.objResponse.sat);
    print(dayValue.map((e) => e));
    // var val = dayValue.indexWhere((element) => element == 0);
    for (int i = 0; i < dayValue.length; i++) {
      if (dayValue[i] == 0) {
        int cIndx = i == 0 ? 7 : i;
        dayIndex.add(cIndx);
      }
    }
    print(dayIndex);
    return dayIndex;
  }

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.only(left: 16.0, top: 16),
      child: Column(
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Text(
                'Appointment Date',
                style: TextStyle(
                  fontSize: 25,
                  fontWeight: FontWeight.bold,
                ),
              ),
              IconButton(
                icon: Icon(
                  Icons.calendar_today,
                  // color: cViolet,
                ),
                onPressed: () {
                  List<int> filteredList = sanitizeDate(widget.chamberData);
                  showDatePicker(
                      context: context,
                      initialDate: DateTime.now(),
                      firstDate: DateTime.now(),
                      lastDate: DateTime(2025, 12),
                      selectableDayPredicate: (DateTime val) {
                        for (int i = 0; i < filteredList.length; i++) {
                          if (val.weekday == filteredList[i]) return false;
                        }
                        return true;
                      }).then((pickedDate) {
                    // String formattedDate = DateFormat.yMMMMEEEEd().format(pickedDate).toString();
                    var dateFormat = DateFormat('EEEE, dd-MMM-yyyy');
                    String formattedDate = dateFormat.format(pickedDate);
                    setState(() {
                      schedule = formattedDate.toString();
                    });
                  });
                },
              )
            ],
          ),
          Padding(
            padding: const EdgeInsets.only(top: 8.0, bottom: 8.0, right: 16.0),
            child: Container(
              decoration: BoxDecoration(
                  border: Border.all(color: cViolet),
                  borderRadius: BorderRadius.all(Radius.circular(10))),
              child: Padding(
                padding: const EdgeInsets.all(8.0),
                child: Column(
                  children: [
                    Text(
                      schedule,
                      style: TextStyle(
                        fontSize: 16,
                        fontWeight: FontWeight.bold,
                        color: schedule == "select schedule"
                            ? Colors.red
                            : Colors.green,
                      ),
                    ),
                    SizedBox(height: 10),
                    ListView.builder(
                        shrinkWrap: true,
                        physics: NeverScrollableScrollPhysics(),
                        itemCount: widget.chamberData.objResponse.drConsultFeeList.length,
                        itemBuilder: (context, index) {
                          var bookingInfo = widget.chamberData.objResponse.drConsultFeeList[index];
                          return BookingTile(
                            consultType: bookingInfo.consultType.toString(),
                            consultFee: bookingInfo.consultFee.toString(),
                            onTapBtn: () {
                              schedule == "select schedule"
                              ? Fluttertoast.showToast(
                                msg: "Please select your appointment date!",
                                toastLength: Toast.LENGTH_SHORT,
                                gravity: ToastGravity.BOTTOM,
                                timeInSecForIosWeb: 1,
                                backgroundColor: Colors.green,
                                textColor: Colors.white,
                                fontSize: 16.0,
                              )
                              : showDialog(
                                context: context,
                                builder: (context) {
                                  return BookingDecisionDialog(
                                    imageUrl: widget.imageUrl,
                                    drName: widget.drName,
                                    schedule: schedule,
                                    drInfo: widget.drInfo,
                                    chamberInfo: widget.chamberData,
                                    consultType: bookingInfo.consultType,
                                    appointmentDate: schedule,
                                    consultationFee: bookingInfo.consultFee.toString(),
                                  );
                              });
                            },
                          );
                        }),
                  ],
                ),
              ),
            ),
          )
        ],
      ),
    );
  }
}
