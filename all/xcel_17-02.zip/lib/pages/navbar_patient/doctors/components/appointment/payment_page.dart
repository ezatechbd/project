import 'package:cool_alert/cool_alert.dart';
import 'package:dotted_border/dotted_border.dart';
import 'package:flutter/material.dart';
import 'package:health_line_bd/config/common_const.dart';
import 'package:health_line_bd/pages/navbar_patient/bottom_navbar_patient.dart';
import 'package:health_line_bd/widgets/custom_text_field.dart';

import 'dialog/payment_req_success_dialog.dart';

class PaymentPage extends StatefulWidget {
  final String consultationFee;
  const PaymentPage({
    Key key,
    @required this.consultationFee,
  }) : super(key: key);

  @override
  _PaymentPageState createState() => _PaymentPageState();
}

class _PaymentPageState extends State<PaymentPage> with SingleTickerProviderStateMixin {
  TabController _tabController;
  int tabIndex = 0;
  List<String> categories = ["Mobile Money", "Insurance/Corporate"];

  /*:::::::::::::::::::::::::::::::: MOBILE MONEY TAB ::::::::::::::::::::::::::::::::*/
  final TextEditingController trxIdController = new TextEditingController();
  final TextEditingController mobileNoController = new TextEditingController();
  final TextEditingController amountController = new TextEditingController();

  /*:::::::::::::::::::::::::::::::: INSURANCE/CORPORATE TAB ::::::::::::::::::::::::::::::::*/
  final TextEditingController companyNameController = new TextEditingController();
  final TextEditingController insuranceNoController = new TextEditingController();
  final TextEditingController expDateController = new TextEditingController();
  final TextEditingController reqAmountController = new TextEditingController();

  @override
  void initState() {
    super.initState();
    _tabController = new TabController(vsync: this, length: categories.length);
  }

  @override
  void dispose() {
    _tabController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return DefaultTabController(
      length: categories.length,
      child: Scaffold(
        appBar: AppBar(
          toolbarHeight: 50,
          brightness: Brightness.dark,
          bottom: TabBar(
            // isScrollable: true,
            onTap: (index){
              setState(() {
                tabIndex = index;
              });
              // print(tabIndex);
            },
            tabs: List<Widget>.generate(categories.length, (int index) {
                // print(categories[index]);
                return Tab(text: categories[index]);
              },
            ),
          ),
        ),
        body: TabBarView(
          controller: _tabController,
          physics: NeverScrollableScrollPhysics(),
          children: List<Widget>.generate(categories.length, (int index) {
              return SingleChildScrollView(
                child: Padding(
                  padding: const EdgeInsets.all(8.0),
                  child: Column(
                    children: [
                      HeadingTextTile(title: "Payment Information"),
                      PaymentInfoTextTile(
                        title: '1. Merchant Number:',
                        value: '0247543654',
                      ),
                      PaymentInfoTextTile(
                        title: '2. Momo ID:',
                        value: '555849',
                      ),
                      SizedBox(height: 16),
                      HeadingTextTile(title: "Amount to Pay"),
                      SizedBox(height: 16),
                      DottedBorder(
                        color: Colors.black,
                        padding: EdgeInsets.fromLTRB(20, 10, 20, 10),
                        strokeWidth: 1,
                        child: Text(
                          widget.consultationFee,
                          textAlign: TextAlign.center,
                          style: TextStyle(fontSize: 30, fontWeight: FontWeight.w400),
                        ),
                      ),
                      SizedBox(height: 16),
                      Text(
                        'Note: Please Enter Your Payment Receipt \nDetails in the Fields Below-',
                        textAlign: TextAlign.center,
                        style: TextStyle(fontSize: 15, fontWeight: FontWeight.w500, color: primaryColor),
                      ),
                      SizedBox(height: 16),
                      HeadingTextTile(title: "Payment Receipt Details"),
                      SizedBox(height: 16),
                      tabIndex == 0 ? Column(
                        children: [
                          CustomtextField(nameController: trxIdController, labeltext: 'Your Transaction ID', horizontalPadding: 32),
                          CustomtextField(nameController: mobileNoController, labeltext: 'Your Mobile No', horizontalPadding: 32),
                          CustomtextField(nameController: amountController, labeltext: 'Amount', horizontalPadding: 32),
                        ],
                      ) : Column(
                        children: [
                          CustomtextField(nameController: companyNameController, labeltext: 'Company Name', horizontalPadding: 32),
                          CustomtextField(nameController: insuranceNoController, labeltext: 'Insurance/Corporate Number', horizontalPadding: 32),
                          CustomtextField(nameController: expDateController, labeltext: 'Expiry Date (Insurance Only)', horizontalPadding: 32),
                          CustomtextField(nameController: reqAmountController, labeltext: 'Enter Required Amount', horizontalPadding: 32),
                        ],
                      ),
                      SizedBox(height: 16),
                      ElevatedButton(
                        onPressed: () {
                          CoolAlert.show(
                            context: context,
                            type: CoolAlertType.warning,
                            showCancelBtn: true,
                            confirmBtnText: "Submit",
                            title: "Submission Alert",
                            text: "Do you want to submit",
                            onConfirmBtnTap: (){
                              Navigator.of(context).pop();
                              Navigator.pushAndRemoveUntil(
                                context,
                                MaterialPageRoute(builder: (context) => BottomNavBarPatient(switchTabIndex: 1)),
                                (route) => false,
                              );
                              showDialog(
                                context: context,
                                builder: (context){
                                  return PaymentReqSuccessDialog(
                                    doctorName: 'Dr. Rezaul Karim',
                                    patientName: 'Md. Enamul Haque',
                                    consultationDate: 'Thursday, Frb 17, 2022',
                                    status: 'Paid',
                                    consultationFee: '225.00',
                                  );
                                },
                              );
                            },
                          );
                        },
                        style: ButtonStyle(
                          backgroundColor: MaterialStateProperty.all(primaryColor),
                          shape: MaterialStateProperty.all<RoundedRectangleBorder>(
                            RoundedRectangleBorder(borderRadius: BorderRadius.circular(5.0))
                          ),
                        ),
                        child: Text('  Submit  '),
                      ),
                    ],
                  ),
                ),
              );
            },
          ),
        ),
      ),
    );
  }
}


/*:::::::::::::::::::::::::::::::::::::::::: WIDGETS ::::::::::::::::::::::::::::::::::::::::::*/
class PaymentInfoTextTile extends StatelessWidget {
  final String title;
  final String value;
  const PaymentInfoTextTile({
    Key key,
    @required this.title,
    @required this.value,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.fromLTRB(8, 16, 8, 0),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Text(title, style: TextStyle(fontSize: 16)),
          Container(
            width: 160,
            decoration: BoxDecoration(border: Border.all(color: primaryColor, width: 1.5)),
            child: Padding(
              padding: const EdgeInsets.all(8.0),
              child: Text(value, textAlign: TextAlign.center, style: TextStyle(fontSize: 24, color: primaryColor, fontWeight: FontWeight.bold)),
            ),
          ),
        ],
      ),
    );
  }
}

class HeadingTextTile extends StatelessWidget {
  final String title;
  const HeadingTextTile({
    Key key,
    @required this.title,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Container(
      width: double.infinity,
      height: 50,
      decoration: BoxDecoration(
        color: primaryColor,
        borderRadius: BorderRadius.all(Radius.circular(5))
      ),
      child: Center(
        child: Text(
          title,
          style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold, color: Colors.white),
        ),
      ),
    );
  }
}