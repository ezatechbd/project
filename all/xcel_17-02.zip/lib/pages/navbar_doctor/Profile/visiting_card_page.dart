import 'package:flutter/material.dart';
import 'package:health_line_bd/config/sp_utils.dart';
import 'package:health_line_bd/pages/navbar_doctor/Profile/components/visiting_card/doctor_visiting_card.dart';

class VisitingCardPage extends StatefulWidget {
  const VisitingCardPage({Key key}) : super(key: key);

  @override
  _VisitingCardPageState createState() => _VisitingCardPageState();
}

class _VisitingCardPageState extends State<VisitingCardPage> {
  String selectedVisitingCard;
  Color visitingCardColor;
  @override
  void initState() {
    getVistingCardFromSP();
    getVistingCardColorFromSP();
    super.initState();
  }

  getVistingCardFromSP() async {
    String value = await SharedPref().getVisitingCard();
    setState(() {
      selectedVisitingCard = value;
    });
    print('Selected Visiting Card: $selectedVisitingCard');
  }

  getVistingCardColorFromSP() async {
    String value = await SharedPref().getVisitingCardColor();
    if (value == 'red') {
      setState(() {
        visitingCardColor = Colors.red;
      });
    } else if (value == 'orange') {
      setState(() {
        visitingCardColor = Colors.orange;
      });
    } else {
      setState(() {
        visitingCardColor = Colors.blue;
      });
    }
    print('Visiting Card Color: $value');
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Center(
        child: selectedVisitingCard == 'card1'
        ? DrVisitingCard1(setVisitingCardColor: visitingCardColor)
        : Container(),
      ),
    );
  }
}
