import 'package:flutter/material.dart';
import 'components/blood_req_card_tile.dart';
import 'components/blood_req_summary_tile.dart';

class BloodDonorPage extends StatelessWidget {
  const BloodDonorPage({Key key }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    var size = MediaQuery.of(context).size;
    return SizedBox(
      child: Scaffold(
        backgroundColor: Color(0xFFe9e7e8),
        body: SizedBox(
          height: size.height,
          child: Column(
            children: [
              BloodRequestSummaryTile(
                appBarTitle: 'Blood Donors',
                availableStatus: '291',
                requestStatus: '481',
              ),
              Expanded(
                child: Padding(
                  padding: const EdgeInsets.only(top: 50.0),
                  child: ListView.builder(
                    itemCount: 15,
                    shrinkWrap: true,
                    padding: const EdgeInsets.all(8.0),
                    itemBuilder: (context, index){
                      return BloodRequestCardTile(
                        requestType: 'AVAILABLE',
                        bloodGroup: 'B+',
                        name: 'Md. Enamul Haque',
                        age: '24',
                        gender: 'Male',
                        address: 'Rampura',
                        mobileNo: '+8801843498350',
                        requestTime: '12hrs',
                      );
                    }),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}