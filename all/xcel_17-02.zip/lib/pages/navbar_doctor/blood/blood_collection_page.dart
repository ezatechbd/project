import 'package:flutter/material.dart';
import 'package:health_line_bd/config/common_const.dart';
import 'package:health_line_bd/pages/navbar_doctor/blood/blood_donor_page.dart';
import 'package:health_line_bd/pages/navbar_doctor/blood/blood_request_page.dart';
import 'components/blood_card_tile.dart';

class BloodCollectionPage extends StatelessWidget {
  const BloodCollectionPage({Key key }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      appBar: AppBar(
        toolbarHeight: 0,
        elevation: 0.0,
        backgroundColor: Colors.white,
        brightness: Brightness.dark,
      ),
      body: Center(
        child: SingleChildScrollView(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.center,
            children: [
              SizedBox(height: 8),
              Row(
                children: [
                  Icon(Icons.location_on_outlined, color: Colors.red),
                  SizedBox(width: 8),
                  Text('DHAKA', style: TextStyle(color: Colors.black54, fontSize: 16, fontWeight: FontWeight.w500)),
                ],
              ),
              Text('GIVE THE GIFT OF LIFE', style: TextStyle(fontSize: 17, fontWeight: FontWeight.w500, wordSpacing: -1)),
              SizedBox(height: 8),
              RichText(
                text: TextSpan(
                  text: 'DONATE ',
                  style: TextStyle(
                    color: Colors.pink[400],
                    fontSize: 28,
                  ),
                  children: <TextSpan>[
                    TextSpan(
                      text:'BLOOD',
                      style: TextStyle(color: Colors.pink, fontWeight: FontWeight.bold, fontSize: 28),
                    ),
                  ],
                ),
              ),
              SizedBox(height: 16),
              Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Container(
                    height: 100,
                    width: 100,
                    decoration: BoxDecoration(
                      borderRadius: BorderRadius.all(Radius.circular(18)),
                      gradient: LinearGradient(
                        colors: [Colors.pink[200], Colors.pink],
                        begin: Alignment.topCenter,
                        end: Alignment.bottomCenter,
                      )
                    ),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.center,
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        Text('157', style: TextStyle(color: Colors.white, fontSize: 30)),
                        Text('New Blood\nRequested', style: TextStyle(color: Colors.white)),
                      ],
                    ),
                  ),
                  SizedBox(width: 24),
                  Container(
                    height: 100,
                    width: 100,
                    decoration: BoxDecoration(
                      borderRadius: BorderRadius.all(Radius.circular(18)),
                      gradient: LinearGradient(
                        colors: [Colors.green[200], Colors.green],
                        begin: Alignment.topCenter,
                        end: Alignment.bottomCenter,
                      )
                    ),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.center,
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        Text('15k', style: TextStyle(color: Colors.white, fontSize: 30)),
                        Text('Save Lives', style: TextStyle(color: Colors.white)),
                      ],
                    ),
                  ),
                ],
              ),
              SizedBox(height: 16),
              RichText(
                text: TextSpan(
                  text: 'Each Donators can help save upto ',
                  style: TextStyle(color: Colors.grey[400], fontSize: 16),
                  children: <TextSpan>[
                    TextSpan(
                      text:'3 Lives!',
                      style: TextStyle(color: Colors.grey, fontWeight: FontWeight.bold, fontSize: 16),
                    ),
                  ],
                ),
              ),
              Image.asset('assets/images/curve.png', height: 100, width: double.infinity, fit: BoxFit.fill),
              Container(
                height: 300,
                width: double.infinity,
                decoration: BoxDecoration(
                  gradient: LinearGradient(
                    colors: [Color(0xFF0099ff), Colors.blue[100]],
                    begin: Alignment.topCenter,
                    end: Alignment.bottomCenter,
                  ),
                ),
                child: Column(
                  children: [
                    Row(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        /*  */
                        InkWell(
                          onTap: (){
                            Navigator.push(context, MaterialPageRoute(builder: (context) => BloodDonorPage()));
                          },
                          child: BloodCardTile(title: 'Members', subTitle: '35k', icon: Icons.people_alt, primaryColor: Colors.pink),
                        ),
                        SizedBox(width: 24),
                        InkWell(
                          onTap: (){
                            Navigator.push(context, MaterialPageRoute(builder: (context) => BloodRequestPage()));
                          },
                          child: BloodCardTile(title: 'Blood Request', subTitle: '100k', icon: Icons.notifications, primaryColor: cViolet),
                        ),
                      ],
                    ),
                    SizedBox(height: 24),
                    Row(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        BloodCardTile(title: 'Blood Bank', subTitle: 'Map', icon: Icons.location_pin, primaryColor: Colors.teal),
                        SizedBox(width: 24),
                        BloodCardTile(title: 'Other', subTitle: 'More', icon: Icons.settings, primaryColor: Colors.grey),
                      ],
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

