import 'package:flutter/material.dart';

class BloodRequestSummaryTile extends StatelessWidget {
  final String appBarTitle;
  final String availableStatus;
  final String requestStatus;
  const BloodRequestSummaryTile({
    Key key,
    @required this.appBarTitle,
    @required this.availableStatus,
    @required this.requestStatus,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    double statusBarHeight = MediaQuery.of(context).padding.top;
    var size = MediaQuery.of(context).size;
    return Stack(
      clipBehavior: Clip.none,
      children: [
        Container(
          height: 150,
          width: double.infinity,
          padding: EdgeInsets.only(top: statusBarHeight),
          color: Colors.red,
          child: Center(
            child: Padding(
              padding: const EdgeInsets.only(bottom: 55.0),
              child: Text(
                appBarTitle,
                style: TextStyle(fontSize: 20,fontWeight: FontWeight.w500,color: Colors.white),
              ),
            ),
          ),
        ),
        Positioned(
          top: 35,
          left: 10,
          child: Container(
            decoration: BoxDecoration(
              gradient: LinearGradient(colors: [Colors.red[200], Colors.red]),
              border: Border.all(color: Colors.white),
              borderRadius: BorderRadius.all(Radius.circular(8)),
            ),
            child: IconButton(
              icon: Padding(
                padding: const EdgeInsets.only(left: 8.0),
                child: Icon(Icons.arrow_back_ios, color: Colors.white),
              ),
              onPressed: () {
                Navigator.of(context).pop();
              },
            ),
          ),
        ),
        Positioned(
          top: 35,
          right: 10,
          child: Container(
            child: IconButton(
              icon: Padding(
                padding: const EdgeInsets.only(left: 8.0),
                child: Icon(Icons.search, color: Colors.white),
              ),
              onPressed: () {},
            ),
          ),
        ),
        Positioned(
          top: 97,
          child: Container(
            height: 100,
            width: size.width,
            padding: const EdgeInsets.symmetric(horizontal: 10),
            child: Card(
              elevation: 0.0,
              // color: Colors.white,
              shape: RoundedRectangleBorder(borderRadius: BorderRadius.all(Radius.circular(15))),
              child: Padding(
                padding: const EdgeInsets.only(top: 20.0),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceAround,
                  children: [
                    Column(
                      children: [
                        Text(
                          availableStatus,
                          style: TextStyle(fontSize: 28, fontWeight: FontWeight.bold),
                        ),
                        Text(
                          'Available',
                          style: TextStyle(color: Colors.grey),
                        ),
                      ],
                    ),
                    Column(
                      children: [
                        Text(
                          requestStatus,
                          style: TextStyle(fontSize: 28, fontWeight: FontWeight.bold),
                        ),
                        Text(
                          'Requests',
                          style: TextStyle(color: Colors.grey),
                        ),
                      ],
                    ),
                  ],
                ),
              ),
            ),
          ),
        )
      ],
    );
  }
}
