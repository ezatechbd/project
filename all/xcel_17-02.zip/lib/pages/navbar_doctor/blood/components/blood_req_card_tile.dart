import 'package:flutter/material.dart';

class BloodRequestCardTile extends StatelessWidget {
  final String requestType;
  final String bloodGroup;
  final String name;
  final String age;
  final String gender;
  final String address;
  final String mobileNo;
  final String requestTime;
  const BloodRequestCardTile({
    Key key,
    @required this.requestType,
    @required this.bloodGroup,
    @required this.name,
    @required this.age,
    @required this.gender,
    @required this.address,
    @required this.mobileNo,
    @required this.requestTime,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    var size = MediaQuery.of(context).size;
    return Container(
      // height: 180,
      width: double.infinity,
      child: Card(
        // color: Colors.white,
        elevation: 0.0,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(15)),
        child: Padding(
          padding: const EdgeInsets.all(16.0),
          child: Row(
            children: [
              // Column(
              //   children: [
              //     Container(
              //       height: 30,
              //       width: 90,
              //       decoration: BoxDecoration(
              //         color: Colors.red,
              //         borderRadius: BorderRadius.only(
              //           topLeft: Radius.circular(10), 
              //           topRight: Radius.circular(10),
              //         ),
              //       ),
              //       child: Center(
              //         child: Text(
              //           requestType,
              //           style: TextStyle(color: Colors.white, fontSize: 13),
              //         ),
              //       ),
              //     ),
              //     Container(
              //       height: 80,
              //       width: 90,
              //       decoration: BoxDecoration(
              //         color: Color(0xFF393231),
              //         borderRadius: BorderRadius.only(
              //           bottomLeft: Radius.circular(10),
              //           bottomRight: Radius.circular(10),
              //         ),
              //       ),
              //       child: Center(
              //         child: Text(
              //           bloodGroup,
              //           style: TextStyle(
              //             color: Colors.white, fontSize: 30, fontWeight: FontWeight.bold),
              //         ),
              //       ),
              //     ),
              //   ],
              // ),
              Stack(
                children: [
                  Image.asset('assets/images/blood.jpg', height: 70, width: 70),
                  Positioned(
                    top: 30,
                    left: 24,
                    child: Text(bloodGroup, style: TextStyle(color: Colors.white)))
                ],
              ),
              SizedBox(width: 20),
              Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Container(
                    width: size.width - 167,
                    child: Text(
                      name,
                      maxLines: 2,
                      overflow: TextOverflow.ellipsis,
                      style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
                    ),
                  ),
                  SizedBox(height: 8),
                  Container(
                    width: size.width - 167,
                    child: Text(
                      '$age • $gender • $address • $requestTime',
                      maxLines: 2,
                      overflow: TextOverflow.ellipsis,
                      style: TextStyle(fontWeight: FontWeight.w500),
                    ),
                  ),
                  SizedBox(height: 8),
                  Row(
                    children: [
                      Icon(Icons.phone, color: Colors.green ,size: 20),
                      SizedBox(width: 4),
                      Text(
                        '$mobileNo',
                        maxLines: 2,
                        overflow: TextOverflow.ellipsis,
                        style: TextStyle(fontWeight: FontWeight.w500),
                      ),
                    ],
                  ),
                ],
              ),
              Container(color: Colors.red, width: 2, height: 80),
              RotatedBox(
                quarterTurns: 1,
                child: Center(
                  child: Text(
                    requestType,
                    style: TextStyle(fontSize:15, fontWeight: FontWeight.bold),
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
