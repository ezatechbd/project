import 'package:flutter/material.dart';

class BloodCardTile extends StatelessWidget {
  final String title;
  final String subTitle;
  final Color primaryColor;
  final IconData icon;
  const BloodCardTile({
    Key key,
    @required this.title,
    @required this.subTitle,
    @required this.primaryColor,
    @required this.icon,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Container(
      height: 130,
      width: 120,
      decoration: BoxDecoration(
        borderRadius: BorderRadius.all(Radius.circular(18)),
        color: Colors.white,
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.center,
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          CircleAvatar(backgroundColor: primaryColor.withOpacity(0.2), child: Icon(icon, color: primaryColor)),
          Padding(
            padding: const EdgeInsets.symmetric(vertical: 8.0),
            child: Text(title, style: TextStyle(color: Colors.black, fontSize: 15, fontWeight: FontWeight.w500)),
          ),
          Container(
            decoration: BoxDecoration(
              // color: primaryColor,
              borderRadius: BorderRadius.all(Radius.circular(25)),
              gradient: LinearGradient(
                colors: [primaryColor.withOpacity(0.4), primaryColor],
                begin: Alignment.topCenter,
                end: Alignment.bottomCenter,
              ),
            ),
            child: Padding(
              padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 4),
              child: Text(subTitle, style: TextStyle(color: Colors.white, fontSize: 15, fontWeight: FontWeight.w500)),
            )
          ),
        ],
      ),
    );
  }
}