import 'package:flutter/material.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:health_line_bd/config/common_const.dart';
import 'package:health_line_bd/widgets/custom_button.dart';
import 'package:url_launcher/url_launcher.dart';

class RegistrationDialog extends StatelessWidget {
  const RegistrationDialog({
    Key key,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Dialog(
      shape: RoundedRectangleBorder(borderRadius:BorderRadius.circular(20.0)), //this right here
      child: Container(
        height: 250,
        width: double.infinity,
        child: Column(
          // mainAxisAlignment: MainAxisAlignment.center,
          // crossAxisAlignment: CrossAxisAlignment.center,
          children: [
            Container(
              height: 70,
              width: double.infinity,
              decoration: BoxDecoration(
                color: primaryColor,
                borderRadius: BorderRadius.only(topLeft: Radius.circular(20), topRight: Radius.circular(20))
              ),
              child: Center(child: Text('Registration', style: TextStyle(fontSize: 22, fontWeight: FontWeight.bold, color: Colors.white))),
            ),
            Padding(
              padding: const EdgeInsets.symmetric(vertical: 20.0),
              child: Center(
                child: Column(
                  children: [
                    Text('Contact Us To Complete ', style: TextStyle(fontSize: 18, fontWeight: FontWeight.w400, color: Colors.grey)),
                    Text('Your Registration', style: TextStyle(fontSize: 18, fontWeight: FontWeight.w400, color: Colors.grey)),
                  ],
                ),
              ),
            ),
            Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                CustomIconButton(
                  iconData: FontAwesomeIcons.whatsapp,
                  btnBackgroundColor: primaryColor,
                  onBtnTap: () async {
                    const url = "whatsapp://send?phone=+8801919408812";
                    if (await canLaunch(url)) {
                      await launch(url);
                    } else {
                      throw 'Could not launch $url';
                    }
                  },
                ),
                SizedBox(width: 40),
                CustomIconButton(
                  iconData: FontAwesomeIcons.phone,
                  btnBackgroundColor: Colors.grey[600],
                  btnSize: 24,
                  onBtnTap: () async {
                    const url = "tel: +8801919408812";
                    if (await canLaunch(url)) {
                      await launch(url);
                    } else {
                      throw 'Could not launch $url';
                    }
                  },
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }
}
