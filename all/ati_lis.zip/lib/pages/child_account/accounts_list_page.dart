// import 'package:ati_lis/config/common_const.dart';
// import 'package:ati_lis/pages/registration/drop_downs/select_blood_group.dart';
// import 'package:ati_lis/pages/registration/drop_downs/select_gender.dart';
// import 'package:ati_lis/pages/registration/drop_downs/select_maritial_status.dart';
// import 'package:ati_lis/pages/registration/drop_downs/select_relation.dart';
// import 'package:flutter/material.dart';
// import 'package:shared_preferences/shared_preferences.dart';

// import 'account_list_view.dart';
// import 'create_child_account_page.dart';

// class AccountsListPage extends StatelessWidget {
//   const AccountsListPage({Key key}) : super(key: key);

//   @override
//   Widget build(BuildContext context) {
//     return Scaffold(
//       resizeToAvoidBottomInset: true,
//       appBar: AppBar(
//         brightness: Brightness.dark,
//         backgroundColor: cViolet,
//         centerTitle: true,
//         title: Text(
//           'Accounts',
//           //style: TextStyle(fontSize: 19),
//         ),
//         actions: [
//           Padding(
//             padding: const EdgeInsets.only(right: 8.0),
//             child: IconButton(
//               onPressed: () async {
//                 SharedPreferences prefs = await SharedPreferences.getInstance();
//                 String profilePhone = prefs.getString('mobileNo');
//                 SelectGender.mySelection = null;
//                 SelectBloodGroup.mySelection = null;
//                 SelectMaritialStatus.mySelection = null;
//                 SelectRelation.mySelection = null;
//                 Navigator.push(
//                   context,
//                   MaterialPageRoute(
//                     builder: (BuildContext context) => CreateChildAccountPage(
//                       profilePhone: profilePhone,
//                     ),
//                   ),
//                 );
//               },
//               icon: Icon(Icons.add),
//             ),
//           )
//         ],
//       ),
//       body: Center(
//         child: Container(
//           padding: EdgeInsets.symmetric(horizontal: 8.0),
//           child: ListView.builder(
//               itemCount: 10,
//               itemBuilder: (BuildContext context, int index) {
//                 return AccountListView(
//                   name: 'Md Enamul Haque',
//                   email: 'enamulhaque028@gmail.com',
//                   bloodGroup: 'A+',
//                   gender: 'Male',
//                   phone: '+8801718675823',
//                   id: '8601254781',
//                   ageCalcDate: '08/12/1982',
//                 );
//               }),
//         ),
//       ),
//     );
//   }
// }

import 'package:ati_lis/config/common_const.dart';
import 'package:ati_lis/model/accounts_model.dart';
import 'package:ati_lis/pages/profile/user_profile.dart';
import 'package:ati_lis/pages/registration/drop_downs/select_blood_group.dart';
import 'package:ati_lis/pages/registration/drop_downs/select_gender.dart';
import 'package:ati_lis/pages/registration/drop_downs/select_maritial_status.dart';
import 'package:ati_lis/pages/registration/drop_downs/select_relation.dart';
import 'package:ati_lis/services/account_service.dart';
import 'package:ati_lis/services/upload_image_service.dart';
import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'account_list_view.dart';
import 'create_child_account_page.dart';

class AccountsListPage extends StatefulWidget {
  const AccountsListPage({Key key}) : super(key: key);

  @override
  _AccountsListPageState createState() => _AccountsListPageState();
}

class _AccountsListPageState extends State<AccountsListPage> {
  Accounts accountInfo = new Accounts();
  var isLoading = true;

  @override
  void initState() {
    AccountService().fetchAccountInfo().then((data) {
      setState(() {
        accountInfo = data;
        isLoading = false;
      });
    });
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      resizeToAvoidBottomInset: true,
      appBar: AppBar(
        brightness: Brightness.dark,
        backgroundColor: cViolet,
        centerTitle: true,
        title: Text(
          'Accounts',
          //style: TextStyle(fontSize: 19),
        ),
        actions: [
          Padding(
            padding: const EdgeInsets.only(right: 8.0),
            child: IconButton(
              onPressed: () async {
                SharedPreferences prefs = await SharedPreferences.getInstance();
                String profilePhone = prefs.getString('mobileNo');
                SelectGender.mySelection = null;
                SelectBloodGroup.mySelection = null;
                SelectMaritialStatus.mySelection = null;
                SelectRelation.mySelection = null;
                ImageUploadService.fileDownloadUrl = '';
                Navigator.push(
                  context,
                  MaterialPageRoute(
                    builder: (BuildContext context) => CreateChildAccountPage(
                      profilePhone: profilePhone,
                    ),
                  ),
                );
              },
              icon: Icon(Icons.add),
            ),
          )
        ],
      ),
      body: Center(
        child: isLoading
            ? CircularProgressIndicator(
                valueColor: AlwaysStoppedAnimation<Color>(cViolet),
              )
            : Container(
                padding: EdgeInsets.symmetric(horizontal: 8.0),
                child: ListView.builder(
                    itemCount: accountInfo.pRetrnmsg1.length,
                    itemBuilder: (BuildContext context, int index) {
                      return InkWell(
                        onTap: () {
                          accountInfo.pRetrnmsg1[index].approvedfg.toString() ==
                                  '1'
                              ? Navigator.push(
                                  context,
                                  MaterialPageRoute(
                                    builder: (context) => UserProfile(
                                      isIdFromAccount: true,
                                      pId: accountInfo
                                          .pRetrnmsg1[index].patientId
                                          .toString(),
                                    ),
                                  ),
                                )
                              : () {
                                  ScaffoldMessenger.of(context)
                                      .showSnackBar(SnackBar(
                                    content:
                                        Text('Profile is not available yet!'),
                                    duration: Duration(seconds: 2),
                                  ));
                                }();
                        },
                        child: AccountListView(
                          name: accountInfo.pRetrnmsg1[index].patientNm
                              .toString(),
                          email: accountInfo.pRetrnmsg1[index].ptemailNo
                              .toString(),
                          bloodGroup: accountInfo.pRetrnmsg1[index].bldgrpTxt
                              .toString(),
                          gender: accountInfo.pRetrnmsg1[index].sorgndrtxt
                              .toString(),
                          phone: accountInfo.pRetrnmsg1[index].pmobileNo
                              .toString(),
                          id: accountInfo.pRetrnmsg1[index].patientId
                              .toString(),
                          birthDate: accountInfo.pRetrnmsg1[index].caldobFmt
                              .toString(),
                          status: accountInfo.pRetrnmsg1[index].approvedfg
                              .toString(),
                          statusDetails:
                              accountInfo.pRetrnmsg1[index].patIdTxt.toString(),
                          imageUrl: accountInfo.pRetrnmsg1[index].photoLoca
                              .toString(),
                        ),
                      );
                    }),
              ),
      ),
    );
  }
}
