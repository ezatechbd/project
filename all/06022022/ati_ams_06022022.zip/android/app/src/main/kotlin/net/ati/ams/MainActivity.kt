package net.ati.ams

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
