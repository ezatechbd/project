package com.ati.ati_snm

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
