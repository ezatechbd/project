class Languages {
  static const String English = '🇺🇸 ${" "} English';
  static const String Bangla = '🇧🇩 ${" "} Bangla';

  static const List<String> choices = <String>[English, Bangla];
}
