package com.dil.pims

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
