import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:health_line_bd/model/doctor_category_model.dart';
import 'package:health_line_bd/pages/navbar/doctors/components/all_doctors_tile.dart';
import 'package:health_line_bd/pages/navbar/doctors/components/custom_searchbar.dart';
import 'package:health_line_bd/pages/navbar/doctors/doctor_details_page.dart';

class DoctorListPage extends StatefulWidget {
  final List<DoctorList> doctorList;
  const DoctorListPage({Key key, @required this.doctorList}) : super(key: key);

  @override
  _DoctorListPageState createState() => _DoctorListPageState();
}

class _DoctorListPageState extends State<DoctorListPage> {
  List<DoctorList> doctorInfo = [];
  List<DoctorList> displayDoctorInfo = [];
  final TextEditingController controller = TextEditingController();
  bool isSearching = false;
  @override
  void initState() {
    doctorInfo = widget.doctorList;
    displayDoctorInfo = doctorInfo;
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    SystemChrome.setSystemUIOverlayStyle(SystemUiOverlayStyle(
      statusBarColor: Colors.blue, //or set color with: Color(0xFF0000FF)
    ));
    double statusBarHeight = MediaQuery.of(context).padding.top;
    return Scaffold(
      // backgroundColor: kBackgroundColor,
      body: Padding(
        padding: EdgeInsets.only(top: statusBarHeight),
        child: Column(
          children: [
            CustomSearchBar(
              controller: controller,
              onChanged: (text) {
                text = text.toLowerCase();

                setState(() {
                  displayDoctorInfo = doctorInfo.where((value) {
                    var name = value.doctorName.toLowerCase();
                    var degree = value.degree.toString().toLowerCase();
                    var dept = value.departmentName.toString().toLowerCase();
                    var institute =
                        value.instituteName.toString().toLowerCase();
                    return name.contains(text) ||
                        degree.contains(text) ||
                        dept.contains(text) ||
                        institute.contains(text);
                  }).toList();
                });
              },
            ),
            Expanded(
              child: displayDoctorInfo.isEmpty
                  ? Center(
                      child: Text('not matched!'),
                    )
                  : ListView.builder(
                      shrinkWrap: true,
                      itemCount: displayDoctorInfo.length,
                      padding:
                          EdgeInsets.only(bottom: 4, left: 8, right: 8, top: 8),
                      itemBuilder: (context, index) {
                        var drInfo = displayDoctorInfo[index];
                        return InkWell(
                          child: AllDoctorTile(
                            imageUrl: drInfo.imgPath.toString(),
                            name: drInfo.doctorName.toString(),
                            speciality: drInfo.specialityName.toString(),
                            degree: drInfo.degree.toString(),
                            institute: drInfo.instituteName.toString(),
                            departmentName: drInfo.departmentName.toString(),
                            rating: '5.5',
                          ),
                          onTap: () {
                            Navigator.push(
                              context,
                              MaterialPageRoute(
                                builder: (context) => DoctorDetailsPage(
                                  imageUrl: drInfo.imgPath.toString(),
                                  name: drInfo.doctorName.toString(),
                                  speciality: drInfo.specialityName.toString(),
                                  degree: drInfo.degree.toString(),
                                  department: drInfo.departmentName.toString(),
                                  drNo: drInfo.doctorNo.toString(),
                                  currentChember:
                                      drInfo.currentChember.toString(),
                                ),
                              ),
                            );
                          },
                        );
                      }),
            )
          ],
        ),
      ),
    );
  }
}
