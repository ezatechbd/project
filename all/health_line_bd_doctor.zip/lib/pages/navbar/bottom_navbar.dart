import 'package:flutter/material.dart';
import 'package:cool_nav/cool_nav.dart';
import 'package:health_line_bd/pages/navbar/accounts/accounts_list_page.dart';
import 'package:health_line_bd/pages/navbar/profile/user_profile.dart';
import 'package:health_line_bd/pages/navbar/report/patient_report_page.dart.dart';
import 'package:health_line_bd/pages/navbar/settings/settings_page.dart';
import 'package:health_line_bd/pages/navbar/step_counter/step_counter.dart';
import 'home/home_page.dart';

class BottomNavBar extends StatefulWidget {
  BottomNavBar({Key key}) : super(key: key);

  @override
  _BottomNavBarState createState() => _BottomNavBarState();
}

class _BottomNavBarState extends State<BottomNavBar> {
  int currentIndex = 0;

  @override
  void initState() {
    super.initState();
    currentIndex = 0;
  }

  List<Widget> pages = [
    HomePage(),
    // AllDoctorsPage(),
    PatientReportPage(),
    UserProfile(isIdFromAccount: false, pId: ''),
    AccountsListPage(),
    StepCounterPage(),
    SettingsPage(),
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
        // appBar: AppBar(
        //   title: Text('Example'),
        // ),
        body: Center(
          child: pages[currentIndex],
        ),
        bottomNavigationBar: FlipBoxNavigationBar(
          currentIndex: currentIndex,
          verticalPadding: 20.0,
          items: <FlipBoxNavigationBarItem>[
            FlipBoxNavigationBarItem(
              name: 'Home',
              selectedIcon: Icons.home,
              unselectedIcon: Icons.home_outlined,
              selectedBackgroundColor: Colors.deepPurpleAccent[200],
              unselectedBackgroundColor: Colors.deepPurpleAccent[100],
            ),
            FlipBoxNavigationBarItem(
              name: 'Report',
              selectedIcon: Icons.menu_book,
              unselectedIcon: Icons.menu_book_outlined,
              selectedBackgroundColor: Colors.indigoAccent[200],
              unselectedBackgroundColor: Colors.indigoAccent[100],
            ),
            FlipBoxNavigationBarItem(
              name: 'Profile',
              selectedIcon: Icons.person,
              unselectedIcon: Icons.person_outline_outlined,
              selectedBackgroundColor: Colors.greenAccent[200],
              unselectedBackgroundColor: Colors.greenAccent[100],
            ),
            FlipBoxNavigationBarItem(
              name: 'Accounts',
              selectedIcon: Icons.account_box,
              unselectedIcon: Icons.account_box_outlined,
              selectedBackgroundColor: Colors.greenAccent[200],
              unselectedBackgroundColor: Colors.greenAccent[100],
            ),
            FlipBoxNavigationBarItem(
              name: 'Step',
              selectedIcon: Icons.directions_walk,
              unselectedIcon: Icons.directions_walk_outlined,
              selectedBackgroundColor: Colors.blueAccent[200],
              unselectedBackgroundColor: Colors.blueAccent[100],
            ),
            FlipBoxNavigationBarItem(
              name: 'Settings',
              selectedIcon: Icons.settings,
              unselectedIcon: Icons.settings,
              selectedBackgroundColor: Colors.orangeAccent[200],
              unselectedBackgroundColor: Colors.orangeAccent[100],
            ),
          ],
          onTap: (index) {
            setState(() {
              currentIndex = index;
            });
          },
        ));
  }
}
