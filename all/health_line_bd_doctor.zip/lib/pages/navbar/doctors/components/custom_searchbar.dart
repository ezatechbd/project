import 'package:flutter/material.dart';
import 'package:health_line_bd/config/common_const.dart';

class CustomSearchBar extends StatelessWidget {
  final Function(String) onChanged;
  final TextEditingController controller;
  const CustomSearchBar(
      {Key key, @required this.onChanged, @required this.controller})
      : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Container(
      height: 130,
      decoration: BoxDecoration(
        color: Colors.blue,
        borderRadius: BorderRadius.only(
          bottomRight: Radius.circular(30),
        ),
      ),
      child: Row(
        children: [
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 8.0),
            child: Text(
              'Find\nDoctors',
              style: TextStyle(
                color: Colors.white,
                fontSize: 35,
                fontWeight: FontWeight.bold,
              ),
            ),
          ),
          Expanded(
            child: Padding(
              padding: const EdgeInsets.only(right: 8.0),
              child: Row(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Expanded(
                    child: TextField(
                      controller: controller,
                      onChanged: (value) {
                        onChanged(value);
                      },
                      style: const TextStyle(fontSize: 14),
                      decoration: const InputDecoration(
                        filled: true,
                        focusColor: Colors.red,
                        hoverColor: Colors.red,
                        fillColor: Color(0xFFFFFFFF),
                        hintText: 'Search',
                        hintStyle: TextStyle(color: Colors.grey),
                        // prefixIcon: const Icon(Icons.search),
                        contentPadding: EdgeInsets.only(left: 16, right: 8),
                        enabledBorder: OutlineInputBorder(
                          borderSide: BorderSide(color: Colors.transparent),
                          borderRadius: BorderRadius.only(
                            topLeft: Radius.circular(5.0),
                            bottomLeft: Radius.circular(5.0),
                          ),
                        ),
                        focusedBorder: UnderlineInputBorder(
                          borderSide: BorderSide(color: Colors.transparent),
                        ),
                      ),
                    ),
                  ),
                  Container(
                    height: 48,
                    width: 50,
                    decoration: BoxDecoration(
                      color: cViolet,
                      borderRadius: BorderRadius.only(
                        bottomRight: Radius.circular(5.0),
                        topRight: Radius.circular(5.0),
                      ),
                    ),
                    child: const Icon(
                      Icons.search,
                      color: Colors.white,
                    ),
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }
}
