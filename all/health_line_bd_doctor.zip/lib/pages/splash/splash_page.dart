import 'package:flutter/material.dart';
import 'package:health_line_bd/animation/splash_animation/animation_screen.dart';
import 'package:health_line_bd/pages/navbar/bottom_navbar.dart';
import 'package:health_line_bd/widgets/custom_slider.dart';

class SplashPage extends StatelessWidget {
  const SplashPage({
    Key key,
    @required this.email,
    @required this.otp,
    @required this.saveUser,
  }) : super(key: key);
  final String email;
  final String otp;
  final String saveUser;
  @override
  Widget build(BuildContext context) {
    // SystemChrome.setEnabledSystemUIOverlays(SystemUiOverlay.values); //disable full screen
    return Material(
      child: Stack(
        children: <Widget>[
          (saveUser.toString() == 'null' ||
                  email.toString() == 'null' ||
                  otp.toString() == 'null')
              // (saveUser.toString() == 'null' || email.toString() == 'null')
              ? CustomSlider()
              : BottomNavBar(),
          IgnorePointer(
            child: AnimationScreen(color: Colors.blue),
          ),
        ],
      ),
    );
  }
}
