// class LoginResponseModel {
//   final String token;
//   final String error;

//   LoginResponseModel({this.token, this.error});

//   factory LoginResponseModel.fromJson(Map<String, dynamic> json) {
//     return LoginResponseModel(
//       token: json["token"] != null ? json["token"] : "",
//       error: json["error"] != null ? json["error"] : "",
//     );
//   }
// }

class LoginRequestModel {
  String email;
  String password;
  int appVersionCode;
  String deviceModel;
  String osVersion;
  String fcmToken;

  LoginRequestModel({
    this.email,
    this.password,
    this.appVersionCode,
    this.deviceModel,
    this.osVersion,
    this.fcmToken,
  });

  Map<String, dynamic> toJson() {
    Map<String, dynamic> map = {
      "P_MOBIAPS_ID": "31",
      "P_USRLOGINID": email.trim(),
      "P_UPASSWORDS": password.trim(),
      "P_MA_VERSION": appVersionCode.toString() ?? '',
      "P_MDEV_MODEL": deviceModel ?? '',
      "P_OS_VERSION": osVersion ?? '',
      "P_FCM_REG_ID": fcmToken ?? '',
    };

    return map;
  }
}
