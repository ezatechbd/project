package com.example.drug_medi_info_fa

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
