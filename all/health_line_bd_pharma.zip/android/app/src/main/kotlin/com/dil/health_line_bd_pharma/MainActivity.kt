package com.dil.health_line_bd_pharma

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
