const MEDI_DATA = [
  {
    "name": "Acepril",
    "brand": "Lisinopril USP",
    "price": 2.99,
    "image":
        "http://drug-international.com/uploads/product_images/1562213768Acepril%2010.jpg"
  },
  {
    "name": "Bacmax",
    "brand": "Baclofen USP",
    "price": 4.99,
    "image": "http://drug-international.com/uploads/images/bacmax10.jpg"
  },
  {
    "name": "Cardinex",
    "brand": "Enoxaparin Sodium BP",
    "price": 1.49,
    "image":
        "http://drug-international.com/uploads/product_images/1562214441Cardinex%2040.jpg"
  },
  {
    "name": "Dovonex",
    "brand": "Calcipotriol BP",
    "price": 2.99,
    "image": "http://drug-international.com/uploads/product_images/Dovonex.jpg"
  },
  {
    "name": "Eyetear",
    "brand": "Povidone BP",
    "price": 9.49,
    "image": "http://drug-international.com/uploads/product_images/EYETEAR.jpg"
  },
  {
    "name": "Famotid",
    "brand": "Famotidine USP",
    "price": 4.49,
    "image":
        "http://drug-international.com/uploads/product_images/Famotid_20.jpg"
  },
  {
    "name": "Getinib",
    "brand": "Gefitinib INN",
    "price": 17.99,
    "image":
        "http://drug-international.com/uploads/product_images/15438308981531112521Getinib_c.jpg"
  },
  {
    "name": "HopSo",
    "brand": "Sofosbuvir INN",
    "price": 2.99,
    "image":
        "http://drug-international.com/uploads/product_images/1517300144Hopso.jpg"
  },
  {
    "name": "Indapa-SR",
    "brand": "Indaoamide BP",
    "price": 6.99,
    "image":
        "http://drug-international.com/uploads/product_images/Indapa-SR.jpg"
  }
];
