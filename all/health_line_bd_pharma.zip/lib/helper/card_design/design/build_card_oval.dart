import 'package:flutter/material.dart';
import 'package:mediinfo/helper/card_design/paint/custom_paint_oval.dart';
import 'package:mediinfo/services/db/db_provider.dart';
import 'package:smooth_star_rating/smooth_star_rating.dart';
import 'package:mediinfo/models/country.dart';

class BuildCardOval extends StatefulWidget {
  final Color color;
  final String drugIcon;
  final String productName;
  final String genericName;
  final String thumbLink;
  final String productNo;

  const BuildCardOval({
    Key key,
    @required this.color,
    @required this.drugIcon,
    @required this.productName,
    @required this.genericName,
    @required this.thumbLink,
    @required this.productNo,
  }) : super(key: key);

  @override
  _BuildCardOvalState createState() => _BuildCardOvalState();
}

class _BuildCardOvalState extends State<BuildCardOval> {
  double cpWidth = 500;
  var rating = 0.0;
  var favBtnValue = 0;
  var shortListBtnValue = 0;
  DBProvider dbProvider = DBProvider();
  List<AddToFavourite> favData = [];
  List<AddToShortList> shortListData = [];

  // this initState() is only for getting the length of favorite and shortlist products
  // if initState() isn't created then "favData.length" and "shortListData.length" will be []
  @override
  void initState() {
    super.initState();
    dbProvider.getProductsFromFavourite().then((res) {
      setState(() {
        favData = res;
      });
    });
    dbProvider.getProductsFromShortList().then((res) {
      setState(() {
        shortListData = res;
      });
    });
  }

  // get all products no from favorite
  List<String> getFavProductNo() {
    List<String> allFavProductNo = [];
    setState(() {
      int i;
      for (i = 0; i < favData.length; i++) {
        allFavProductNo.add(favData[i].productNo.toString());
      }
    });
    return allFavProductNo;
  }

  // get all products no from short list
  List<String> getShortListProductNo() {
    List<String> allShortListProductNo = [];
    setState(() {
      int i;
      for (i = 0; i < shortListData.length; i++) {
        allShortListProductNo.add(shortListData[i].productNo.toString());
      }
    });
    return allShortListProductNo;
  }

  @override
  Widget build(BuildContext context) {
    var width = MediaQuery.of(context).size.width;
    return Container(
      height: 143,
      width: width,
      padding: EdgeInsets.all(5.0),
      child: Card(
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(12.0),
        ),
        shadowColor: Colors.grey,
        elevation: 8.0,
        child: Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Container(
                  padding: EdgeInsets.all(5.0),
                  child: CircleAvatar(
                    radius: 12,
                    backgroundImage: NetworkImage(widget.drugIcon),
                    backgroundColor: Colors.transparent,
                  ),
                ),
                Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Container(
                      padding: EdgeInsets.only(top: 5.0),
                      width: width / 3.34,
                      child: Text(
                        widget.productName,
                        overflow: TextOverflow.ellipsis,
                        maxLines: 1,
                        style: TextStyle(
                          fontSize: 18,
                          fontWeight: FontWeight.w600,
                        ),
                      ),
                    ),
                    SizedBox(
                      height: 8,
                    ),
                    Container(
                      width: width / 3.34,
                      height: 33,
                      child: Text(
                        widget.genericName,
                        overflow: TextOverflow.ellipsis,
                        maxLines: 2,
                        style: TextStyle(color: Colors.grey),
                      ),
                    ),
                    Container(
                      //width: width / 3.34,
                      child: SmoothStarRating(
                        rating: rating,
                        size: 18,
                        starCount: 5,
                        color: Colors.red,
                        borderColor: Colors.red,
                        onRated: (value) {
                          setState(() {
                            rating = value;
                          });
                          //print(rating);
                        },
                      ),
                    ),
                    SizedBox(
                      height: 8,
                    ),
                    Container(
                      child: Row(
                        children: [
                          InkWell(
                            onTap: () {
                              //print(getFavProductNo());
                              var btnVal;
                              (favBtnValue == 0 &&
                                      getFavProductNo()
                                              .contains(widget.productNo) ==
                                          false)
                                  ? () {
                                      dbProvider
                                          .addToFavourite(
                                              widget.productNo,
                                              widget.productName,
                                              widget.genericName,
                                              widget.thumbLink)
                                          .then((value) {
                                        ScaffoldMessenger.of(context)
                                            .showSnackBar(
                                          SnackBar(
                                            content: const Text(
                                                'Product has been added to favorite'),
                                          ),
                                        );
                                      });
                                      btnVal = 1;
                                    }()
                                  : () {
                                      dbProvider
                                          .deleteProductFromFavourite(
                                              widget.productNo)
                                          .then((value) {
                                        ScaffoldMessenger.of(context)
                                            .showSnackBar(
                                          SnackBar(
                                            content: const Text(
                                                'Product has been removed from favorite'),
                                          ),
                                        );
                                      });
                                      btnVal = 0;
                                    }();
                              setState(() {
                                favBtnValue = btnVal;
                              });
                            },
                            child: (favBtnValue == 0 &&
                                    getFavProductNo()
                                            .contains(widget.productNo) ==
                                        false)
                                ? Icon(
                                    Icons.favorite_outline,
                                    color: Colors.grey,
                                  )
                                : Icon(
                                    Icons.favorite,
                                    color: Colors.red,
                                  ),
                          ),
                          SizedBox(
                            width: 10,
                          ),
                          InkWell(
                            onTap: () {
                              print(getShortListProductNo());
                              var btnVal;
                              (shortListBtnValue == 0 &&
                                      getShortListProductNo()
                                              .contains(widget.productNo) ==
                                          false)
                                  ? () {
                                      dbProvider
                                          .addToShortList(
                                              widget.productNo,
                                              widget.productName,
                                              widget.genericName,
                                              widget.thumbLink)
                                          .then((value) {
                                        ScaffoldMessenger.of(context)
                                            .showSnackBar(
                                          SnackBar(
                                            content: const Text(
                                                'Product has been added to short list'),
                                          ),
                                        );
                                      });
                                      btnVal = 1;
                                    }()
                                  : () {
                                      dbProvider
                                          .deleteProductFromShortList(
                                              widget.productNo)
                                          .then((value) {
                                        ScaffoldMessenger.of(context)
                                            .showSnackBar(
                                          SnackBar(
                                            content: const Text(
                                                'Product has been removed from short list'),
                                          ),
                                        );
                                      });
                                      btnVal = 0;
                                    }();
                              setState(() {
                                shortListBtnValue = btnVal;
                              });
                            },
                            child: (shortListBtnValue == 0 &&
                                    getShortListProductNo()
                                            .contains(widget.productNo) ==
                                        false)
                                ? Icon(
                                    Icons.add_circle_outline,
                                    color: Colors.grey,
                                  )
                                : Icon(
                                    Icons.check_outlined,
                                    color: Colors.green,
                                  ),
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
              ],
            ),
            Stack(
              children: [
                Container(
                  //color: Colors.green,
                  child: CustomPaint(
                    size: Size(
                      200,
                      (cpWidth * 0.3).toDouble(),
                    ), //You can Replace [WIDTH] with your desired width for Custom Paint and height will be calculated automatically
                    painter: RPSCustomPainterOval(getColor: widget.color),
                  ),
                ),
                Positioned(
                  left: 97,
                  top: 20,
                  child: Container(
                    width: 88.0,
                    height: 88.0,
                    decoration: new BoxDecoration(
                      color: Colors.white,
                      shape: BoxShape.circle,
                      image: new DecorationImage(
                        fit: BoxFit.fill,
                        image: new NetworkImage(
                          widget.thumbLink,
                        ),
                      ),
                    ),
                  ),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }
}
