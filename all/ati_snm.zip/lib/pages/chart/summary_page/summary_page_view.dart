import 'dart:developer';
import 'package:dil_app/api/db/db_provider.dart';
import 'package:dil_app/config/common_const.dart';
import 'package:dil_app/model/client_info_model.dart';
import 'package:flutter/material.dart';

class SummaryView extends StatefulWidget {
  final String days;

  const SummaryView({
    Key key,
    @required this.days,
  }) : super(key: key);

  @override
  _SummaryViewState createState() => _SummaryViewState();
}

class _SummaryViewState extends State<SummaryView> {
  List<CountStatusByDate> statusData = [];
  List<CountPriorityByDate> priorityData = [];
  var isLoading = true;
  @override
  void initState() {
    log('Days: ${widget.days}');
    DBProvider().getTicketStatusByDate(widget.days).then((value) {
      setState(() {
        statusData = value;
        addAdditionalStatusData();
      });
    }).then((value) {
      DBProvider().getTicketPriorityByDate(widget.days).then((value) {
        setState(() {
          priorityData = value;
          addAdditionalPriorityData();
          isLoading = false;
        });
      });
    });
    super.initState();
  }

  addAdditionalStatusData() {
    int getStatus(String id) {
      var open = statusData.where((value) => value.tKTSTUSID == id).toList();
      return open.length;
    }

    getStatus('1') == 0
        ? statusData.addAll({CountStatusByDate(count: 0, tICKSTATUS: 'Open')})
        : Container();
    if (getStatus('3') == 0 && getStatus('2') == 0) {
      statusData.addAll({
        CountStatusByDate(count: 0, tICKSTATUS: 'Work In Progress / On Hold')
      });
    } else {
      getStatus('3') == 0
          ? statusData.addAll(
              {CountStatusByDate(count: 0, tICKSTATUS: 'Work In Progress')})
          : Container();
      getStatus('2') == 0
          ? statusData
              .addAll({CountStatusByDate(count: 0, tICKSTATUS: 'On Hold')})
          : Container();
    }
    if (getStatus('4') == 0 && getStatus('5') == 0) {
      statusData.addAll(
          {CountStatusByDate(count: 0, tICKSTATUS: 'Resolved/Not Resolved')});
    } else {
      getStatus('4') == 0
          ? statusData
              .addAll({CountStatusByDate(count: 0, tICKSTATUS: 'Resolved')})
          : Container();
      getStatus('5') == 0
          ? statusData
              .addAll({CountStatusByDate(count: 0, tICKSTATUS: 'Not Resolved')})
          : Container();
    }
    getStatus('9') == 0
        ? statusData.addAll({CountStatusByDate(count: 0, tICKSTATUS: 'Closed')})
        : Container();
  }

  addAdditionalPriorityData() {
    int getStatus(String id) {
      var open = priorityData.where((value) => value.tKTPRIID == id).toList();
      return open.length;
    }

    getStatus('1') == 0
        ? priorityData.addAll({
            CountPriorityByDate(count: 0, ticketPriority: 'Critical / Urgent')
          })
        : Container();
    getStatus('2') == 0
        ? priorityData.addAll(
            {CountPriorityByDate(count: 0, ticketPriority: 'Major / High')})
        : Container();
    getStatus('3') == 0
        ? priorityData.addAll(
            {CountPriorityByDate(count: 0, ticketPriority: 'Minor / Medium')})
        : Container();
    getStatus('4') == 0
        ? priorityData.addAll(
            {CountPriorityByDate(count: 0, ticketPriority: 'Trivial / Low')})
        : Container();
    getStatus('5') == 0
        ? priorityData.addAll(
            {CountPriorityByDate(count: 0, ticketPriority: 'Not Defined Yet')})
        : Container();
  }

  @override
  Widget build(BuildContext context) {
    return isLoading
        ? Center(
            child: CircularProgressIndicator(),
          )
        : Padding(
            padding: const EdgeInsets.only(bottom: 8.0),
            child: Center(
              child: SingleChildScrollView(
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                  children: [
                    Container(),
                    statusData.isEmpty
                        ? Center(
                            child: Text('No status history found!'),
                          )
                        : Card(
                            shape: RoundedRectangleBorder(
                                borderRadius: BorderRadius.circular(10)),
                            child: Row(
                              children: [
                                Container(
                                  decoration: BoxDecoration(
                                    borderRadius: BorderRadius.only(
                                      topLeft: Radius.circular(10),
                                      bottomLeft: Radius.circular(10),
                                    ),
                                    color: Colors.green,
                                  ),
                                  height: (statusData.length * 62).toDouble(),
                                  width: 50,
                                  child: RotatedBox(
                                    quarterTurns: -1,
                                    child: Center(
                                      child: Text(
                                        'STATUS',
                                        style: TextStyle(
                                          fontSize: 15,
                                          fontWeight: FontWeight.bold,
                                          color: Colors.white,
                                        ),
                                      ),
                                    ),
                                  ),
                                ),
                                Expanded(
                                  child: ListView.builder(
                                    physics:
                                        const NeverScrollableScrollPhysics(),
                                    shrinkWrap: true,
                                    itemCount: statusData.length,
                                    itemBuilder:
                                        (BuildContext context, int index) {
                                      // String tStatus =
                                      //     snapshot.data[index].tICKSTATUS.toString();
                                      // String tStatusVal =
                                      //     tStatus == "null" ? "Unnamed" : tStatus;
                                      Color textColor = statusData[index]
                                                  .tKTSTUSID ==
                                              '1'
                                          ? Color(0xff3366cc)
                                          : statusData[index].tKTSTUSID == '2'
                                              ? Colors.amber
                                              : statusData[index].tKTSTUSID ==
                                                      '3'
                                                  ? Colors.purple
                                                  : statusData[index]
                                                              .tKTSTUSID ==
                                                          '4'
                                                      ? Colors.grey
                                                      : statusData[index]
                                                                  .tKTSTUSID ==
                                                              '5'
                                                          ? Colors.red
                                                          : statusData[index]
                                                                      .tKTSTUSID ==
                                                                  '9'
                                                              ? Colors.green
                                                              : Colors.grey;
                                      return Padding(
                                        padding: const EdgeInsets.symmetric(
                                            horizontal: 16, vertical: 8),
                                        child: Column(
                                          children: [
                                            Row(
                                              mainAxisAlignment:
                                                  MainAxisAlignment
                                                      .spaceBetween,
                                              children: [
                                                Text(
                                                  '${statusData[index].tICKSTATUS.toString()}',
                                                  style: TextStyle(
                                                      color: textColor),
                                                ),
                                                Container(
                                                    width: 30,
                                                    height: 30,
                                                    decoration: BoxDecoration(
                                                      color: Colors.green,
                                                      shape: BoxShape.circle,
                                                      // borderRadius: new BorderRadius.circular(30.0),
                                                    ),
                                                    child: Center(
                                                      child: Text(
                                                        '${statusData[index].count.toString()}',
                                                        style: TextStyle(
                                                            color:
                                                                Colors.white),
                                                      ),
                                                    )),
                                              ],
                                            ),
                                            Divider()
                                          ],
                                        ),
                                      );
                                    },
                                  ),
                                ),
                              ],
                            ),
                          ),
                    // SizedBox(height: 16),
                    priorityData.isEmpty
                        ? Center(
                            child: Text('No priority history found!'),
                          )
                        : Padding(
                            padding: const EdgeInsets.only(top: 8.0),
                            child: Card(
                              shape: RoundedRectangleBorder(
                                borderRadius: BorderRadius.circular(10),
                              ),
                              child: Row(
                                children: [
                                  Container(
                                    decoration: BoxDecoration(
                                      borderRadius: BorderRadius.only(
                                        topLeft: Radius.circular(10),
                                        bottomLeft: Radius.circular(10),
                                      ),
                                      color: Color(PrimaryColor),
                                    ),
                                    height:
                                        (priorityData.length * 62).toDouble(),
                                    width: 50,
                                    child: RotatedBox(
                                      quarterTurns: -1,
                                      child: Center(
                                        child: Text(
                                          'PRIORITY',
                                          style: TextStyle(
                                            fontSize: 15,
                                            fontWeight: FontWeight.bold,
                                            color: Colors.white,
                                          ),
                                        ),
                                      ),
                                    ),
                                  ),
                                  Expanded(
                                    child: ListView.builder(
                                      physics:
                                          const NeverScrollableScrollPhysics(),
                                      shrinkWrap: true,
                                      itemCount: priorityData.length,
                                      itemBuilder:
                                          (BuildContext context, int index) {
                                        // String tStatus =
                                        //     snapshot.data[index].tICKSTATUS.toString();
                                        // String tStatusVal =
                                        //     tStatus == "null" ? "Unnamed" : tStatus;
                                        Color textColor = priorityData[index]
                                                    .tKTPRIID ==
                                                '1'
                                            ? Color(0xffdc3912)
                                            : priorityData[index].tKTPRIID ==
                                                    '2'
                                                ? Color(0xff3366cc)
                                                : priorityData[index]
                                                            .tKTPRIID ==
                                                        '3'
                                                    ? Color(0xfffdbe19)
                                                    : priorityData[index]
                                                                .tKTPRIID ==
                                                            '4'
                                                        ? Color(0xff7CFC00)
                                                        : priorityData[index]
                                                                    .tKTPRIID ==
                                                                '5'
                                                            ? Colors.purple
                                                            : Colors.grey;
                                        return Padding(
                                          padding: const EdgeInsets.symmetric(
                                              horizontal: 16, vertical: 8),
                                          child: Column(
                                            children: [
                                              Row(
                                                mainAxisAlignment:
                                                    MainAxisAlignment
                                                        .spaceBetween,
                                                children: [
                                                  Text(
                                                    '${priorityData[index].ticketPriority.toString()}',
                                                    style: TextStyle(
                                                        color: textColor),
                                                  ),
                                                  Container(
                                                      width: 30,
                                                      height: 30,
                                                      decoration: BoxDecoration(
                                                        color:
                                                            Color(PrimaryColor),
                                                        shape: BoxShape.circle,
                                                        // borderRadius: new BorderRadius.circular(30.0),
                                                      ),
                                                      child: Center(
                                                        child: Text(
                                                          '${priorityData[index].count.toString()}',
                                                          style: TextStyle(
                                                              color:
                                                                  Colors.white),
                                                        ),
                                                      )),
                                                ],
                                              ),
                                              Divider()
                                            ],
                                          ),
                                        );
                                      },
                                    ),
                                  ),
                                ],
                              ),
                            ),
                          ),
                    Container(),
                  ],
                ),
              ),
            ),
          );
  }
}
