import 'package:dil_app/config/common_const.dart';
import 'package:dil_app/pages/account/account_list.dart';
import 'package:dil_app/pages/chart/chart.dart';
import 'package:dil_app/pages/complain/complain_page.dart';
import 'package:dil_app/pages/faqs/faqs_page.dart';
import 'package:dil_app/pages/login/login_page.dart';
import 'package:dil_app/pages/recommendation/recommendation_page.dart';
import 'package:dil_app/pages/settings/settings_page.dart';
import 'package:dil_app/pages/ticketing/support_ticket.dart';
import 'package:flutter/material.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:shared_preferences/shared_preferences.dart';

import 'custom_side_menu.dart';

class DrawerMenu extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Container(
      // width: (MediaQuery.of(context).size.width) * 0.65,
      width: 250,
      child: Drawer(
        child: ListView(
          padding: EdgeInsets.zero,
          children: <Widget>[
            DrawerHeader(
              decoration: BoxDecoration(
                gradient: LinearGradient(
                  colors: <Color>[
                    Color(PrimaryColor),
                    Color(PrimaryColor),
                  ],
                ),
              ),
              child: SingleChildScrollView(
                child: Container(
                  child: Column(
                    children: <Widget>[
                      CircleAvatar(
                        backgroundColor: Colors.transparent,
                        radius: 50,
                        backgroundImage: AssetImage('assets/images/logo.png'),
                      ),
                      SizedBox(
                        height: 10,
                      ),
                      Text(
                        ChartPage.userName.toString(),
                        style: TextStyle(
                          color: titleTextColor,
                          fontSize: 16,
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ),
            CustomListTile(
              Icons.home,
              'Home',
              () {
                Navigator.push(
                  context,
                  MaterialPageRoute(
                    builder: (context) => ChartPage(),
                  ),
                );
              },
            ),
            CustomListTile(
              Icons.assignment,
              'Support Ticket Status',
              () {
                Navigator.push(
                  context,
                  MaterialPageRoute(
                    builder: (context) => ShowTicket(),
                  ),
                );
              },
            ),
            CustomListTile(
              Icons.account_circle,
              'Request for Account',
              () {
                Navigator.push(
                  context,
                  MaterialPageRoute(
                    builder: (BuildContext ctx) => AccountListPage(),
                  ),
                );
                //Navigator.of(context).pop();
              },
            ),
            CustomListTile(
              Icons.recommend,
              'Recommendation',
              () {
                Navigator.push(
                  context,
                  MaterialPageRoute(
                    builder: (BuildContext ctx) => RecommendationPage(),
                  ),
                );
                //Navigator.of(context).pop();
              },
            ),
            CustomListTile(
              Icons.support_agent_rounded,
              'Complain',
              () {
                Navigator.push(
                  context,
                  MaterialPageRoute(
                    builder: (BuildContext ctx) => ComplainPage(),
                  ),
                );
                //Navigator.of(context).pop();
              },
            ),
            CustomListTile(
              Icons.help_sharp,
              'FAQs',
              () {
                Navigator.push(
                  context,
                  MaterialPageRoute(
                    builder: (BuildContext ctx) => FaqsPage(),
                  ),
                );
                //Navigator.of(context).pop();
              },
            ),
            CustomListTile(
              FontAwesomeIcons.signOutAlt,
              'Logout',
              () async {
                SharedPreferences prefs = await SharedPreferences.getInstance();
                prefs.remove('email');
                Navigator.pushReplacement(
                  context,
                  MaterialPageRoute(
                    builder: (BuildContext ctx) => LoginPage(),
                  ),
                );
                //Navigator.of(context).pop();
              },
            ),
            CustomListTile(
              Icons.settings,
              'Settings',
              () {
                Navigator.push(
                  context,
                  MaterialPageRoute(
                    builder: (BuildContext ctx) => SettingsPage(),
                  ),
                );
                //Navigator.of(context).pop();
              },
            ),
          ],
        ),
      ),
    );
  }
}
