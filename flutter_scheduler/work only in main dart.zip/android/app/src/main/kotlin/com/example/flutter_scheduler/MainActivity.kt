package com.example.flutter_scheduler

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
