package com.example.receive_sharing_intent

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
