import 'package:ati_lis/custom/timeline_widget.dart';
import 'package:ati_lis/model/profile_model.dart';
import 'package:ati_lis/services/profile_service.dart';
import 'package:flutter/material.dart';
import 'dart:ui';
import 'package:ati_lis/config/common_const.dart';
import 'package:ati_lis/custom/user_info.dart';
import 'package:ati_lis/pages/profile/flip_card/flip_card.dart';
// import 'package:font_awesome_flutter/font_awesome_flutter.dart';

class UserProfile extends StatefulWidget {
  @override
  _UserProfileState createState() => _UserProfileState();
}

class _UserProfileState extends State<UserProfile> {
  TextEditingController _nameController = TextEditingController();
  bool isEditable = false;
  Profile profileData = new Profile();
  var isLoading = true;

  @override
  void initState() {
    ProfileService().fetchProfileData().then((data) {
      setState(() {
        profileData = data;
        isLoading = false;
      });
    });
    super.initState();
    _nameController.text =
        "MD. Enamul Haque"; // Setting the initial value for the field.
  }

  @override
  Widget build(BuildContext context) {
    // double statusBarHeight = MediaQuery.of(context).padding.top;

    return Scaffold(
      resizeToAvoidBottomInset: true,
      appBar: AppBar(
        brightness: Brightness.dark,
        backgroundColor: cViolet,
        centerTitle: true,
        title: Text(
          'Profile',
          //style: TextStyle(fontSize: 19),
        ),
      ),
      body: Container(
        // padding: EdgeInsets.only(
        //   top: statusBarHeight,
        //   //left: 20,
        // ),
        child: SingleChildScrollView(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              isLoading
                  ? Center(
                      child: CircularProgressIndicator(
                        valueColor: AlwaysStoppedAnimation<Color>(cViolet),
                      ),
                    )
                  : FlipCard(
                      profileInfo: profileData.pReturnmsg[0],
                    ),
              // SizedBox(
              //   height: 15,
              // ),
              Container(
                padding: EdgeInsets.only(left: 10),
                child: isLoading
                    ? Center(
                        child: CircularProgressIndicator(
                          valueColor: AlwaysStoppedAnimation<Color>(cViolet),
                        ),
                      )
                    : profileData.pReturnmsg.isEmpty
                        ? Center(
                            child: Text('No data found!'),
                          )
                        : Column(
                            children: [
                              Row(
                                children: [
                                  CustomTimeLine(height: 50),
                                  SizedBox(
                                    width: 5.0,
                                  ),
                                  Expanded(
                                      flex: 15,
                                      child: !isEditable
                                          ? Column(
                                              crossAxisAlignment:
                                                  CrossAxisAlignment.start,
                                              children: [
                                                Text(
                                                  'Name',
                                                  style: TextStyle(
                                                    color: Colors.green,
                                                    fontSize: 16,
                                                    fontWeight: FontWeight.bold,
                                                  ),
                                                ),
                                                Text(
                                                  // _nameController.text,
                                                  profileData
                                                      .pReturnmsg[0].patientNm
                                                      .toString(),
                                                  style:
                                                      TextStyle(fontSize: 18),
                                                ),
                                                Divider(
                                                  thickness: 1.0,
                                                ),
                                                SizedBox(
                                                  height: 8,
                                                ),
                                              ],
                                            )
                                          : TextFormField(
                                              controller: _nameController,
                                              textInputAction:
                                                  TextInputAction.done,
                                              onFieldSubmitted: (value) {
                                                print('Name Changed!');
                                                setState(() {
                                                  isEditable = false;
                                                  _nameController.text = value;
                                                });
                                              })),
                                  // IconButton(
                                  //     icon: Icon(
                                  //       FontAwesomeIcons.edit,
                                  //       size: 15,
                                  //     ),
                                  //     onPressed: () {
                                  //       setState(() {
                                  //         isEditable = true;
                                  //       });
                                  //     })
                                ],
                              ),
                              // UserInfo(
                              //   title: 'Force Name',
                              //   info: 'Bangladesh Army',
                              // ),
                              // UserInfo(
                              //   title: 'Rank',
                              //   info: 'Major General',
                              // ),
                              // UserInfo(
                              //   title: 'Working Unit',
                              //   info: 'Dhaka',
                              // ),
                              UserInfo(
                                title: 'Nationality',
                                info: profileData.pReturnmsg[0].nationalty
                                    .toString(),
                              ),
                              UserInfo(
                                title: 'Date of Birth',
                                info: profileData.pReturnmsg[0].calcptDob
                                    .toString(),
                              ),
                              UserInfo(
                                title: 'Religion',
                                info: profileData.pReturnmsg[0].relgnName
                                    .toString(),
                              ),
                              UserInfo(
                                title: 'Gender',
                                info: profileData.pReturnmsg[0].sorgndrtxt
                                    .toString(),
                              ),
                              UserInfo(
                                title: 'Blood Group',
                                info: profileData.pReturnmsg[0].bldgrpTxt
                                    .toString(),
                              ),
                              UserInfo(
                                title: 'Maritial Status',
                                info: profileData.pReturnmsg[0].mstusName
                                    .toString(),
                              ),
                              UserInfo(
                                title: 'Phone',
                                info: profileData.pReturnmsg[0].pmobileNo
                                    .toString(),
                              ),
                              UserInfo(
                                title: 'Email',
                                info: profileData.pReturnmsg[0].ptemailNo
                                    .toString(),
                              ),
                              UserInfo(
                                title: 'National ID',
                                info: profileData.pReturnmsg[0].nationalid
                                    .toString(),
                              ),
                              UserInfo(
                                title: 'Present Address',
                                info: profileData.pReturnmsg[0].ptAddress
                                    .toString(),
                              ),
                              UserInfo(
                                title: 'Patient Status',
                                info: profileData.pReturnmsg[0].patStatus
                                    .toString(),
                              ),
                            ],
                          ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
