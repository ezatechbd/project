import 'dart:convert';
import 'dart:io';
import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import 'package:http/http.dart' as http;
// import 'package:http_parser/http_parser.dart';

class PickImages extends StatefulWidget {
  static String base64Image = '';
  // static List base64ImageList = [];
  @override
  _PickImagesState createState() => _PickImagesState();
}

class _PickImagesState extends State<PickImages> {
  List<Object> images = [];
  Future<PickedFile> _imageFile;
  bool _isVisible = false;
  final picker = ImagePicker();

  Future _onAddImageClick(int index, int type) async {
    if (images != null)
      setState(() {
        // ignore: deprecated_member_use
        _imageFile = picker.getImage(
          source: type == 1 ? ImageSource.camera : ImageSource.gallery,
          imageQuality: 50,
        );
        getFileImage(index);
      });
  }

  void getFileImage(int index) async {
    _imageFile.then((file) async {
      //SharedPreferences prefs = await SharedPreferences.getInstance();
      //var userCode = prefs.getString('userCode');
      setState(() {
        ImageUploadModel imageUpload = new ImageUploadModel();
        imageUpload.imageFile = File(file.path);
        List<int> imageBytes = File(file.path).readAsBytesSync();
        PickImages.base64Image = base64Encode(imageBytes);
        print(PickImages.base64Image);
        images.replaceRange(index, index + 1, [imageUpload]);

        //PickImages.base64ImageList = List();
        // PickImages.base64ImageList.add(base64Image);
        //log('Image Test $base64ImageList');

        //post image with additional informations
        // sendImage(
        //     base64Image.toString(), //post image to server
        //     SelectClient.mySelection['CLIENTS_ID'].toString(),
        //     SelectProject.mySelection['PROJECT_ID'].toString(),
        //     userCode.toString());
      });
    });
  }

  void showImageBox() {
    setState(() {
      _isVisible = !_isVisible;
    });
  }

  @override
  void initState() {
    super.initState();
    setState(() {
      images.add("Add Image");
      // images.add("Add Image");
      // images.add("Add Image");
      // images.add("Add Image");
      // images.add("Add Image");
      // images.add("Add Image");
    });
  }

  @override
  Widget build(BuildContext context) {
    // var width = MediaQuery.of(context).size.width;
    return Column(
      children: <Widget>[
        Container(
          //padding: EdgeInsets.only(right: 5),
          child: Card(
            elevation: 5,
            child: ListTile(
              trailing: Icon(Icons.attachment),
              title: Text('Upload Your ID Card Photo'),
              onTap: () {
                showImageBox();
              },
            ),
          ),
        ),
        Visibility(
          visible: _isVisible,
          child: Column(
            children: [
              Padding(
                padding: const EdgeInsets.only(top: 5.0, right: 5.0),
                child: GridView.count(
                  shrinkWrap: true,
                  crossAxisCount: 3,
                  childAspectRatio: 1,
                  children: List.generate(images.length, (index) {
                    if (images[index] is ImageUploadModel) {
                      ImageUploadModel uploadModel = images[index];
                      // //base64 image
                      // List<int> imageBytes =
                      //     uploadModel.imageFile.readAsBytesSync();
                      // PickImages.base64Image = base64Encode(
                      //     imageBytes); //'base64Image' holds the base64 image string
                      return Card(
                        clipBehavior: Clip.antiAlias,
                        child: Stack(
                          children: <Widget>[
                            Image.file(
                              uploadModel.imageFile,
                              fit: BoxFit.cover,
                              width: 300,
                              height: 300,
                            ),
                            Positioned(
                              right: 5,
                              top: 5,
                              child: InkWell(
                                child: Icon(
                                  Icons.remove_circle,
                                  size: 20,
                                  color: Colors.red,
                                ),
                                onTap: () {
                                  PickImages.base64Image = '';
                                  setState(() {
                                    images.replaceRange(
                                        index, index + 1, ['Add Image']);
                                  });
                                },
                              ),
                            ),
                            RaisedButton(
                              child: Text('imgInfo'),
                              onPressed: () {
                                print(
                                    "${uploadModel.imageFile.lengthSync() / 1024} KB"); //print image size in kb
                                print(uploadModel
                                    .imageFile.path); //print image path
                                // log(PickImages.base64Image);
                                uploadImage(File(uploadModel.imageFile.path));
                              },
                            ),
                          ],
                        ),
                      );
                    } else {
                      return Card(
                        child: IconButton(
                          icon: Icon(Icons.camera_alt),
                          onPressed: () {
                            showModalBottomSheet(
                              context: context,
                              builder: (BuildContext context) {
                                return SafeArea(
                                  child: Container(
                                    child: new Wrap(
                                      children: <Widget>[
                                        new ListTile(
                                          leading: new Icon(Icons.photo_camera),
                                          title: new Text('Camera'),
                                          onTap: () {
                                            _onAddImageClick(index, 1);
                                            Navigator.of(context).pop();
                                          },
                                        ),
                                        new ListTile(
                                            leading:
                                                new Icon(Icons.photo_library),
                                            title: new Text('Gallery'),
                                            onTap: () {
                                              _onAddImageClick(index, 2);
                                              Navigator.of(context).pop();
                                            }),
                                      ],
                                    ),
                                  ),
                                );
                              },
                            );
                          },
                        ),
                      );
                    }
                  }),
                ),
              ),
            ],
          ),
        ),
      ],
    );
  }
}

class ImageUploadModel {
  File imageFile;

  ImageUploadModel({
    this.imageFile,
  });
}

// uploadImage(File file) async {
//   print('vndf');
//   var postUri =
//       Uri.parse("http://192.168.0.29:9050/tourplan_ws/file/uploadFile");
//   var request = new http.MultipartRequest("POST", postUri);
//   // Map<String, String> headers = {'Content-Type': 'multipart/form-data'};
//   // request.headers["Content-Type"] = 'multipart/form-data';
//   // request.fields['user'] = 'blah';
//   request.files.add(
//     new http.MultipartFile.fromBytes(
//       'file',
//       await File.fromUri(Uri.parse(file.path)).readAsBytes(),
//       // contentType: MediaType("image", "${file.path.split(".").last}"),
//     ),
//   );

//   request.send().then((response) {
//     print(response.statusCode);
//     if (response.statusCode == 200) {
//       print("Uploaded!");
//     } else {
//       print("Failed!");
//     }
//   });
// }

uploadImage(File file) async {
  var request = http.MultipartRequest('POST',
      Uri.parse('http://gpst.billingdil.com:8088/tourplan_ws/file/uploadFile'));
  request.files.add(await http.MultipartFile.fromPath('file', file.path));

  http.StreamedResponse response = await request.send();

  if (response.statusCode == 200) {
    print(await response.stream.bytesToString());
  } else {
    print(response.reasonPhrase);
  }
}
