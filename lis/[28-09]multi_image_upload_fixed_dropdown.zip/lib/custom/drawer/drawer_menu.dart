import 'dart:convert';
import 'package:ati_lis/config/common_const.dart';
import 'package:ati_lis/custom/drawer/side_menu.dart';
import 'package:ati_lis/pages/child_account/create_child_account_page.dart';
import 'package:ati_lis/pages/home/home_page.dart';
import 'package:ati_lis/pages/login/login_page.dart';
// import 'package:ati_lis/pages/login/login_page.dart';
import 'package:ati_lis/pages/profile/user_profile.dart';
import 'package:ati_lis/pages/registration/drop_downs/select_blood_group.dart';
import 'package:ati_lis/pages/registration/drop_downs/select_gender.dart';
import 'package:ati_lis/pages/registration/drop_downs/select_maritial_status.dart';
import 'package:ati_lis/pages/registration/drop_downs/select_relation.dart';
import 'package:flutter/material.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:shared_preferences/shared_preferences.dart';
// import 'package:shared_preferences/shared_preferences.dart';

class DrawerMenu extends StatefulWidget {
  @override
  _DrawerMenuState createState() => _DrawerMenuState();
}

class _DrawerMenuState extends State<DrawerMenu> {
  String patientName;
  bool isLoading = true;
  Map accountListdropdown;
  Map mySelection;
  getRespFromSP() async {
    SharedPreferences prefs = await SharedPreferences.getInstance();
    accountListdropdown = json.decode(prefs.getString('apiresp'));
    patientName = prefs.getString('patientName');
    setState(() {
      isLoading = false;
    });
  }

  @override
  void initState() {
    getRespFromSP();
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    var width = MediaQuery.of(context).size.width;
    return Container(
      width: width * 0.68,
      //width: 250,
      child: Drawer(
        child: Column(
          children: [
            Expanded(
              child: ListView(
                padding: EdgeInsets.zero,
                children: <Widget>[
                  DrawerHeader(
                    decoration: BoxDecoration(
                      gradient: LinearGradient(
                        colors: <Color>[
                          cViolet,
                          cSky,
                        ],
                      ),
                    ),
                    child: SingleChildScrollView(
                      child: Container(
                        child: Column(
                          children: <Widget>[
                            CircleAvatar(
                              backgroundColor: Colors.transparent,
                              radius: 50,
                              backgroundImage:
                                  AssetImage('assets/images/logo.jpeg'),
                            ),
                            SizedBox(
                              height: 10,
                            ),
                          ],
                        ),
                      ),
                    ),
                  ),
                  Padding(
                    padding: const EdgeInsets.symmetric(horizontal: 8.0),
                    child: isLoading
                        ? Center(
                            child: Text('loading'),
                          )
                        : DropdownButton<Map>(
                            isExpanded: true,
                            hint: Text(patientName.toString() == 'null'
                                ? accountListdropdown['P_RETURNMSG4'][0]
                                        ["patient_nm"]
                                    .toString()
                                : patientName.toString()),
                            items: accountListdropdown['P_RETURNMSG4']
                                .map<DropdownMenuItem<Map>>((item) {
                              return new DropdownMenuItem<Map>(
                                value: item,
                                child: Padding(
                                  padding: const EdgeInsets.only(left: 8.0),
                                  child: new Text(
                                    item["patient_nm"].toString(),
                                  ),
                                ),
                              );
                            }).toList(),
                            onChanged: (newVal) async {
                              SharedPreferences prefs =
                                  await SharedPreferences.getInstance();
                              setState(() {
                                mySelection = newVal == null ? {} : newVal;
                                print(
                                  mySelection.toString(),
                                  // mySelection['g_id']
                                  //     .toString(),
                                );
                                String patientId =
                                    mySelection['patient_id'].toString();
                                String patientName =
                                    mySelection['patient_nm'].toString();
                                prefs.setString('patientId', patientId);
                                prefs.setString('patientName', patientName);
                                Navigator.pop(context);
                                Navigator.pushReplacement(
                                    context,
                                    MaterialPageRoute(
                                        builder: (context) => MyHomePage()));
                                // showAlertDialogue();
                              });
                            },
                            value: mySelection,
                          ),
                  ),
                  CustomListTile(
                    icon: Icons.home,
                    text: 'Home',
                    onTap: () {
                      Navigator.pop(context);
                      Navigator.pushReplacement(
                        context,
                        MaterialPageRoute(
                          builder: (BuildContext context) => MyHomePage(),
                        ),
                      );
                    },
                  ),
                  CustomListTile(
                    icon: Icons.account_circle,
                    text: 'Profile',
                    onTap: () {
                      // print(apiresp);
                      Navigator.pop(context);
                      Navigator.push(
                        context,
                        MaterialPageRoute(
                          builder: (BuildContext context) => UserProfile(),
                        ),
                      );
                    },
                  ),
                  CustomListTile(
                    icon: Icons.account_box,
                    text: 'Create Child Account',
                    onTap: () async {
                      SharedPreferences prefs =
                          await SharedPreferences.getInstance();
                      String profilePhone = prefs.getString('mobileNo');
                      SelectGender.mySelection = null;
                      SelectBloodGroup.mySelection = null;
                      SelectMaritialStatus.mySelection = null;
                      SelectRelation.mySelection = null;
                      Navigator.pop(context);
                      Navigator.push(
                        context,
                        MaterialPageRoute(
                          builder: (BuildContext context) =>
                              CreateChildAccountPage(
                            profilePhone: profilePhone,
                          ),
                        ),
                      );
                    },
                  ),
                  CustomListTile(
                    icon: FontAwesomeIcons.signOutAlt,
                    text: 'Logout',
                    onTap: () async {
                      SharedPreferences prefs =
                          await SharedPreferences.getInstance();
                      prefs.remove('email');
                      prefs.remove('saveUser');
                      prefs.remove('otp');
                      prefs.remove('patientId');
                      prefs.remove('patientName');
                      prefs.remove('parentId');
                      Navigator.pushReplacement(
                        context,
                        MaterialPageRoute(
                          builder: (BuildContext ctx) => LoginPage(),
                        ),
                      );
                    },
                  ),
                ],
              ),
            ),
            Container(
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceAround,
                children: [
                  Text(
                    'Developed by',
                    style: TextStyle(fontSize: 15),
                  ),
                  Image.asset(
                    'assets/images/ati.png',
                    height: 24,
                    //width: width * 0.20,
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  Future<void> showAlertDialogue() async {
    return showDialog<void>(
      context: context,
      barrierDismissible: false, // user must tap button!
      builder: (BuildContext context) {
        return AlertDialog(
          title: const Text('Switch Account'),
          content: SingleChildScrollView(
            child: Text('Do you want to make this account dafault?'),
          ),
          actions: <Widget>[
            Row(
              children: [
                TextButton(
                  child: const Text('Ignore'),
                  onPressed: () {
                    Navigator.of(context).pop();
                  },
                ),
                TextButton(
                  child: const Text('Approve'),
                  onPressed: () {
                    Navigator.of(context).pop();
                    Navigator.push(context,
                        MaterialPageRoute(builder: (context) => MyHomePage()));
                  },
                ),
              ],
            ),
          ],
        );
      },
    );
  }
}

/******************************************   dropdown account from api  ******************************************/
// import 'dart:convert';

// import 'package:ati_lis/config/common_const.dart';
// import 'package:ati_lis/custom/drawer/side_menu.dart';
// import 'package:ati_lis/pages/child_account/create_child_account_page.dart';
// import 'package:ati_lis/pages/home/home_page.dart';
// import 'package:ati_lis/pages/login/login_page.dart';
// // import 'package:ati_lis/pages/login/login_page.dart';
// import 'package:ati_lis/pages/profile/user_profile.dart';
// import 'package:flutter/material.dart';
// import 'package:font_awesome_flutter/font_awesome_flutter.dart';
// import 'package:shared_preferences/shared_preferences.dart';
// // import 'package:shared_preferences/shared_preferences.dart';
// import 'package:http/http.dart' as http;

// class DrawerMenu extends StatefulWidget {
//   @override
//   _DrawerMenuState createState() => _DrawerMenuState();
// }

// class _DrawerMenuState extends State<DrawerMenu> {
//   var isLoading = true;
//   Map accountListdropdown;
//   Map mySelection;
//   serviceMethod() async {
//     var url = "http://192.168.0.54:8088/ords/ordstest/cmh/fget/";
//     final response = await http.get(url);
//     // final responseJson = json.decode(response.body);
//     // print(responseJson);
//     // print(response.statusCode);

//     if (response.statusCode == 200) {
//       setState(() {
//         isLoading = false;
//         accountListdropdown = json.decode(response.body)['items'][0];
//       });
//     } else {
//       setState(() {
//         isLoading = false;
//       });
//       throw Exception('Failed to load internet');
//     }
//   }

//   @override
//   void initState() {
//     serviceMethod();
//     super.initState();
//   }

//   @override
//   Widget build(BuildContext context) {
//     var width = MediaQuery.of(context).size.width;
//     return Container(
//       width: width * 0.68,
//       //width: 250,
//       child: Drawer(
//         child: Column(
//           children: [
//             Expanded(
//               child: ListView(
//                 padding: EdgeInsets.zero,
//                 children: <Widget>[
//                   DrawerHeader(
//                     decoration: BoxDecoration(
//                       gradient: LinearGradient(
//                         colors: <Color>[
//                           cViolet,
//                           cSky,
//                         ],
//                       ),
//                     ),
//                     child: SingleChildScrollView(
//                       child: Container(
//                         child: Column(
//                           children: <Widget>[
//                             CircleAvatar(
//                               backgroundColor: Colors.transparent,
//                               radius: 50,
//                               backgroundImage:
//                                   AssetImage('assets/images/logo.png'),
//                             ),
//                             SizedBox(
//                               height: 10,
//                             ),
//                           ],
//                         ),
//                       ),
//                     ),
//                   ),
//                   Padding(
//                     padding: const EdgeInsets.symmetric(horizontal: 8.0),
//                     child: isLoading
//                         ? Center(
//                             child: Text('loading'),
//                           )
//                         : DropdownButton<Map>(
//                             isExpanded: true,
//                             hint: Text(accountListdropdown['gender'][0]["g_name"]
//                                 .toString()),
//                             items: accountListdropdown['gender']
//                                 .map<DropdownMenuItem<Map>>((item) {
//                               return new DropdownMenuItem<Map>(
//                                 value: item,
//                                 child: Padding(
//                                   padding: const EdgeInsets.only(left: 8.0),
//                                   child: new Text(
//                                     item["g_name"].toString(),
//                                   ),
//                                 ),
//                               );
//                             }).toList(),
//                             onChanged: (newVal) {
//                               setState(() {
//                                 mySelection = newVal == null ? {} : newVal;
//                                 print(
//                                   mySelection.toString(),
//                                   // mySelection['g_id']
//                                   //     .toString(),
//                                 );
//                                 showAlertDialogue();
//                               });
//                             },
//                             value: mySelection,
//                           ),
//                   ),
//                   CustomListTile(
//                     icon: Icons.home,
//                     text: 'Home',
//                     onTap: () {
//                       Navigator.pop(context);
//                       Navigator.push(
//                         context,
//                         MaterialPageRoute(
//                           builder: (BuildContext context) => MyHomePage(),
//                         ),
//                       );
//                     },
//                   ),
//                   CustomListTile(
//                     icon: Icons.account_circle,
//                     text: 'Profile',
//                     onTap: () {
//                       Navigator.pop(context);
//                       Navigator.push(
//                         context,
//                         MaterialPageRoute(
//                           builder: (BuildContext context) => UserProfile(),
//                         ),
//                       );
//                     },
//                   ),
//                   CustomListTile(
//                     icon: Icons.account_box,
//                     text: 'Create Child Account',
//                     onTap: () async {
//                       SharedPreferences prefs =
//                           await SharedPreferences.getInstance();
//                       String profilePhone = prefs.getString('profile_phone');
//                       Navigator.pop(context);
//                       Navigator.push(
//                         context,
//                         MaterialPageRoute(
//                           builder: (BuildContext context) =>
//                               CreateChildAccountPage(
//                             profilePhone: profilePhone,
//                           ),
//                         ),
//                       );
//                     },
//                   ),
//                   CustomListTile(
//                     icon: FontAwesomeIcons.signOutAlt,
//                     text: 'Logout',
//                     onTap: () async {
//                       SharedPreferences prefs =
//                           await SharedPreferences.getInstance();
//                       prefs.remove('email');
//                       prefs.remove('saveUser');
//                       prefs.remove('otp');
//                       Navigator.pushReplacement(
//                         context,
//                         MaterialPageRoute(
//                           builder: (BuildContext ctx) => LoginPage(),
//                         ),
//                       );
//                     },
//                   ),
//                 ],
//               ),
//             ),
//             Container(
//               child: Row(
//                 mainAxisAlignment: MainAxisAlignment.spaceAround,
//                 children: [
//                   Text('Developed by'),
//                   Image.asset(
//                     'assets/images/ati.png',
//                     height: width * 0.07,
//                     //width: width * 0.20,
//                   ),
//                 ],
//               ),
//             ),
//           ],
//         ),
//       ),
//     );
//   }

//   Future<void> showAlertDialogue() async {
//     return showDialog<void>(
//       context: context,
//       barrierDismissible: false, // user must tap button!
//       builder: (BuildContext context) {
//         return AlertDialog(
//           title: const Text('Switch Account'),
//           content: SingleChildScrollView(
//             child: Text('Do you want to make this account dafault?'),
//           ),
//           actions: <Widget>[
//             Row(
//               children: [
//                 TextButton(
//                   child: const Text('Ignore'),
//                   onPressed: () {
//                     Navigator.of(context).pop();
//                   },
//                 ),
//                 TextButton(
//                   child: const Text('Approve'),
//                   onPressed: () {
//                     Navigator.of(context).pop();
//                     Navigator.push(context,
//                         MaterialPageRoute(builder: (context) => MyHomePage()));
//                   },
//                 ),
//               ],
//             ),
//           ],
//         );
//       },
//     );
//   }
// }
