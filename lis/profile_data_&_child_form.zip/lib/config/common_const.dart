import 'package:flutter/material.dart';

const PrimaryColor = 0xFF9d0c0c;

// Color armyChocolate = Color(0xFF2c1f0e);
// Color armyBrown = Color(0xFF5d3a12);
// Color armyGreen = Color(0xFF384b14);
// Color armyYellow = Color(0xFFada06b);

Color cRed = Color(0xFFb9232c);
Color cSky = Color(0xFF648fd6);
Color cViolet = Color(0xFF34017e);
Color cYellow = Color(0xFFada06b);
Color textBlack = Colors.black;

String liveUrl = 'http://203.130.133.166/ATI-ERP2/api/';
String localUrl = 'http://192.168.0.89/ati-erp/api/';

String baseUrl = liveUrl;
