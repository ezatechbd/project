// class LoginResponseModel {
//   final String token;
//   final String error;

//   LoginResponseModel({this.token, this.error});

//   factory LoginResponseModel.fromJson(Map<String, dynamic> json) {
//     return LoginResponseModel(
//       token: json["token"] != null ? json["token"] : "",
//       error: json["error"] != null ? json["error"] : "",
//     );
//   }
// }

class LoginRequestModel {
  String email;
  String password;
  int appVersionCode;
  String deviceModel;
  String osVersion;
  String fcmToken;

  LoginRequestModel({
    this.email,
    this.password,
    this.appVersionCode,
    this.deviceModel,
    this.osVersion,
    this.fcmToken,
  });

  Map<String, dynamic> toJson() {
    Map<String, dynamic> map = {
      "SAUSERS_ID": "31",
      'USER_EMAIL': email.trim(),
      'UPASSWORDS': password.trim(),
      "MAVER_CODE": appVersionCode.toString(),
      "MDEV_MODEL": deviceModel,
      "OS_VERSION": osVersion,
      "FCM_REG_ID": fcmToken,
    };

    return map;
  }
}
