import 'package:ati_lis/pages/home/home_page.dart';
import 'package:ati_lis/pages/registration/TextFields/mobile-number.dart';
import 'package:ati_lis/pages/registration/TextFields/name_field.dart';
import 'package:ati_lis/pages/registration/drop_downs/age/select_age_day.dart';
import 'package:ati_lis/pages/registration/drop_downs/age/select_age_month.dart';
import 'package:ati_lis/pages/registration/drop_downs/age/select_age_year.dart';
import 'package:ati_lis/pages/registration/drop_downs/birthday/select_birth_day.dart';
import 'package:ati_lis/pages/registration/drop_downs/birthday/select_birth_month.dart';
import 'package:ati_lis/pages/registration/drop_downs/birthday/select_birth_year.dart';
import 'package:ati_lis/pages/registration/drop_downs/select_blood_group.dart';
import 'package:ati_lis/pages/registration/drop_downs/select_gender.dart';
import 'package:cool_alert/cool_alert.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'dart:convert';
import 'dart:ui';
import 'package:http/http.dart' as http;

class CreateChildAccountPage extends StatefulWidget {
  final String profilePhone;
  const CreateChildAccountPage({Key key, @required this.profilePhone})
      : super(key: key);

  @override
  _CreateChildAccountPageState createState() => _CreateChildAccountPageState();
}

class _CreateChildAccountPageState extends State<CreateChildAccountPage> {
  final _formKey = GlobalKey<FormState>();
  bool _autoValidate = false;
  var isLoading = true;
  bool isChecked = false;
  Map ticketListdropdown;
  TextEditingController nameController = new TextEditingController();
  TextEditingController phoneController = new TextEditingController();

  dropDownServiceMethod() async {
    var url = "http://192.168.0.95:8088/ords/ordstest/cmh/fget/";
    final response = await http.get(url);
    // final responseJson = json.decode(response.body);
    // print(responseJson);
    // print(response.statusCode);

    if (response.statusCode == 200) {
      setState(() {
        isLoading = false;
        ticketListdropdown = json.decode(response.body)['items'][0];
      });
    } else {
      setState(() {
        isLoading = false;
      });
      throw Exception('Failed to load internet');
    }
  }

  @override
  void initState() {
    dropDownServiceMethod();
    phoneController.text = widget.profilePhone;
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    //change status bar properties
    SystemChrome.setSystemUIOverlayStyle(SystemUiOverlayStyle(
      // statusBarColor: Colors.red,
      statusBarBrightness: Brightness.dark,
    ));
    var height = MediaQuery.of(context).size.height;
    var width = MediaQuery.of(context).size.width;
    var textStyle = TextStyle(
      color: Colors.black.withOpacity(0.6),
      fontWeight: FontWeight.w500,
    );
    return Scaffold(
      body: Stack(children: [
        ConstrainedBox(
            constraints: const BoxConstraints.expand(),
            child: Image.network(
                'https://s3.pixers.pics/pixers/700/FO/43/63/56/74/700_FO43635674_30a1af2f7975f2b9e0d1e1fb490a42fe.jpg',
                fit: BoxFit.cover)),
        Opacity(
          opacity: 0.3,
          child: Container(
            decoration: new BoxDecoration(
              gradient: LinearGradient(
                begin: Alignment.topRight,
                end: Alignment.bottomLeft,
                colors: [Colors.blue, Colors.purpleAccent],
              ),
            ),
          ),
        ),
        Center(
          child: ClipRect(
            child: BackdropFilter(
              filter: ImageFilter.blur(sigmaX: 10.0, sigmaY: 10.0),
              child: Padding(
                padding: const EdgeInsets.only(top: 20.0),
                child: Container(
                  width: width * 0.95,
                  height: height * 0.92,
                  padding: EdgeInsets.all(12.0),
                  decoration: BoxDecoration(
                      color: Colors.grey.shade200.withOpacity(0.5)),
                  child: SingleChildScrollView(
                    child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          IconButton(
                            onPressed: () {
                              Navigator.of(context).pop();
                            },
                            icon: Icon(Icons.arrow_back),
                          ),
                          isLoading
                              ? Center(child: CircularProgressIndicator())
                              : Form(
                                  key: _formKey,
                                  // ignore: deprecated_member_use
                                  autovalidate: _autoValidate,
                                  child: Column(
                                      crossAxisAlignment:
                                          CrossAxisAlignment.start,
                                      children: [
                                        Text('Sign Up',
                                            style: TextStyle(
                                                fontSize: 25,
                                                fontWeight: FontWeight.bold)),
                                        Text(
                                          'It’s quick and easy.',
                                          style: TextStyle(
                                            fontSize: 18,
                                            color:
                                                Colors.black.withOpacity(0.6),
                                          ),
                                        ),
                                        NameField(
                                          autoValidate: _autoValidate,
                                          nameController: nameController,
                                        ),
                                        MobileNumberField(
                                            autoValidate: _autoValidate,
                                            phoneController: phoneController),
                                        Column(
                                            crossAxisAlignment:
                                                CrossAxisAlignment.start,
                                            children: [
                                              Padding(
                                                  padding:
                                                      const EdgeInsets.only(
                                                          top: 8.0),
                                                  child: Row(
                                                      mainAxisAlignment:
                                                          MainAxisAlignment
                                                              .spaceBetween,
                                                      children: [
                                                        Text(
                                                            !isChecked
                                                                ? 'Birthday'
                                                                : 'Age',
                                                            style: textStyle),
                                                        Row(children: [
                                                          Text('Age',
                                                              style: textStyle),
                                                          Checkbox(
                                                              value: isChecked,
                                                              onChanged:
                                                                  (value) {
                                                                setState(() {
                                                                  isChecked =
                                                                      value;
                                                                });
                                                              })
                                                        ])
                                                      ])),
                                              !isChecked
                                                  ? Row(
                                                      mainAxisAlignment:
                                                          MainAxisAlignment
                                                              .spaceBetween,
                                                      children: [
                                                          SelectBirthDay(),
                                                          SelectBirthMonth(),
                                                          SelectBirthYear(),
                                                        ])
                                                  : Row(
                                                      mainAxisAlignment:
                                                          MainAxisAlignment
                                                              .spaceBetween,
                                                      children: [
                                                          SelectAgeYear(),
                                                          SelectAgeMonth(),
                                                          SelectAgeDay(),
                                                        ])
                                            ]),
                                        Padding(
                                          padding:
                                              const EdgeInsets.only(top: 8.0),
                                          child: Row(
                                              mainAxisAlignment:
                                                  MainAxisAlignment
                                                      .spaceBetween,
                                              children: [
                                                Column(
                                                  crossAxisAlignment:
                                                      CrossAxisAlignment.start,
                                                  children: [
                                                    Padding(
                                                      padding:
                                                          const EdgeInsets.only(
                                                              bottom: 5.0),
                                                      child: Text(
                                                        'Gender',
                                                        style: textStyle,
                                                      ),
                                                    ),
                                                    SelectGender(
                                                        projectListdropdown:
                                                            ticketListdropdown),
                                                  ],
                                                ),
                                                Column(
                                                    crossAxisAlignment:
                                                        CrossAxisAlignment
                                                            .start,
                                                    children: [
                                                      Padding(
                                                          padding:
                                                              const EdgeInsets
                                                                      .only(
                                                                  bottom: 5.0),
                                                          child: Text(
                                                              'Blood Group',
                                                              style:
                                                                  textStyle)),
                                                      SelectBloodGroup(
                                                          projectListdropdown:
                                                              ticketListdropdown)
                                                    ]),
                                              ]),
                                        ),
                                        SizedBox(height: 10),
                                        Row(
                                          mainAxisAlignment:
                                              MainAxisAlignment.spaceBetween,
                                          children: [
                                            Container(),
                                            ElevatedButton(
                                                onPressed: () {
                                                  if (_formKey.currentState
                                                      .validate()) {
                                                    Navigator.push(
                                                        context,
                                                        MaterialPageRoute(
                                                            builder: (context) =>
                                                                MyHomePage()));
                                                    CoolAlert.show(
                                                      context: context,
                                                      // width: 350,
                                                      type:
                                                          CoolAlertType.success,
                                                      text:
                                                          "Registration successful!",
                                                    );
                                                    SelectGender.mySelection =
                                                        null;
                                                    SelectBloodGroup
                                                        .mySelection = null;
                                                    _formKey.currentState
                                                        .save();
                                                  } else {
                                                    setState(() {
                                                      _autoValidate = true;
                                                    });
                                                  }
                                                },
                                                child: Text('Submit'),
                                                style: ButtonStyle(
                                                  backgroundColor:
                                                      MaterialStateProperty.all(
                                                          Colors.green),
                                                )),
                                          ],
                                        ),
                                      ]),
                                ),
                        ]),
                  ),
                ),
              ),
            ),
          ),
        ),
      ]),
    );
  }
}
