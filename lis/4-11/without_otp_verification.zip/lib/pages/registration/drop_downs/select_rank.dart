// import 'package:flutter/material.dart';

// class SelectRank extends StatefulWidget {
//   final Map projectListdropdown;
//   static Map mySelection;
//   const SelectRank({
//     Key key,
//     @required this.projectListdropdown,
//   }) : super(key: key);

//   @override
//   _SelectRankState createState() => _SelectRankState();
// }

// class _SelectRankState extends State<SelectRank> {
//   @override
//   Widget build(BuildContext context) {
//     return Padding(
//       padding: const EdgeInsets.only(top: 8.0),
//       child: Container(
//         decoration: BoxDecoration(
//             border: Border.all(width: 1.5, color: Colors.black),
//             borderRadius: BorderRadius.all(Radius.circular(5))),
//         child: DropdownButtonFormField(
//           // underline: SizedBox(),
//           // searchHint: 'Select Project',
//           hint: Padding(
//             padding: const EdgeInsets.only(left: 8.0),
//             child: Text("Select your rank"),
//           ),
//           isExpanded: true,
//           items: widget.projectListdropdown['rank_details']
//               .map<DropdownMenuItem<Map>>((item) {
//             return new DropdownMenuItem<Map>(
//               value: item,
//               child: Padding(
//                 padding: const EdgeInsets.only(left: 8.0),
//                 child: new Text(
//                   item["rank_name"].toString(),
//                 ),
//               ),
//             );
//           }).toList(),
//           onChanged: (newVal) {
//             setState(() {
//               SelectRank.mySelection = newVal == null ? {} : newVal;
//               print(
//                 SelectRank.mySelection.toString(),
//                 // SelectRank.mySelection['PROJT_NAME']
//                 //     .toString(),
//               );
//             });
//           },
//           validator: (newVal) => newVal == null ? ' * required' : null,
//           value: SelectRank.mySelection,
//         ),
//       ),
//     );
//   }
// }

import 'package:flutter/material.dart';

class SelectRank extends StatefulWidget {
  final List rankList;
  static Map mySelection;
  const SelectRank({
    Key key,
    @required this.rankList,
  }) : super(key: key);

  @override
  _SelectRankState createState() => _SelectRankState();
}

class _SelectRankState extends State<SelectRank> {
  List<String> listValue = [
    'Bangladesh Army',
    'Bangladesh Air Force',
    'Bangladesh Navy',
  ];
  String dropdownValue;
  Map rankDetailsDropDown;
  List rankListVal = [];
  filterRankList(String id) {
    rankListVal = widget.rankList
        .where((value) => value['r_id'].toString() == id)
        .toList();
    setState(() {
      rankDetailsDropDown = rankListVal[0];
    });
    print(rankDetailsDropDown);
  }

  bool isVisible = false;

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        Padding(
          padding: const EdgeInsets.only(top: 8.0),
          child: Container(
            decoration: BoxDecoration(
                border: Border.all(width: 1.5, color: Colors.black),
                borderRadius: BorderRadius.all(Radius.circular(5))),
            child: DropdownButtonFormField<String>(
              isExpanded: true,
              hint: Padding(
                padding: const EdgeInsets.only(left: 8.0),
                child: Text("Select Department"),
              ),
              validator: (newVal) => newVal == null ? ' * required' : null,
              value: dropdownValue,
              icon: Icon(Icons.arrow_drop_down),
              // iconSize: 30, //this inicrease the size
              // elevation: 16,
              style: TextStyle(color: Colors.black),
              onChanged: (String newValue) {
                setState(() {
                  SelectRank.mySelection = null;
                  dropdownValue = newValue;
                  String selectDepartment = newValue == 'Bangladesh Army'
                      ? '1'
                      : newValue == 'Bangladesh Air Force'
                          ? '3'
                          : newValue == 'Bangladesh Navy'
                              ? '2'
                              : '';
                  filterRankList(selectDepartment);
                  isVisible = true;
                });

                print(dropdownValue);
              },
              items: listValue.map<DropdownMenuItem<String>>((String value) {
                return DropdownMenuItem<String>(
                  value: value,
                  child: Padding(
                    padding: const EdgeInsets.only(left: 8.0),
                    child: Text(value),
                  ),
                );
              }).toList(),
            ),
          ),
        ),
        isVisible
            ? Padding(
                padding: const EdgeInsets.only(top: 8.0),
                child: Container(
                  decoration: BoxDecoration(
                      border: Border.all(width: 1.5, color: Colors.black),
                      borderRadius: BorderRadius.all(Radius.circular(5))),
                  child: DropdownButtonFormField(
                    // underline: SizedBox(),
                    // searchHint: 'Select Project',
                    hint: Padding(
                      padding: const EdgeInsets.only(left: 8.0),
                      child: Text("Select your rank"),
                    ),
                    isExpanded: true,
                    items: rankDetailsDropDown['r_rank']
                        .map<DropdownMenuItem<Map>>((item) {
                      return new DropdownMenuItem<Map>(
                        value: item,
                        child: Padding(
                          padding: const EdgeInsets.only(left: 8.0),
                          child: new Text(
                            item["r_name"].toString(),
                          ),
                        ),
                      );
                    }).toList(),
                    onChanged: (newVal) {
                      setState(() {
                        SelectRank.mySelection = newVal == null ? {} : newVal;
                        print(
                          SelectRank.mySelection.toString(),
                          // SelectRank.mySelection['PROJT_NAME']
                          //     .toString(),
                        );
                      });
                    },
                    validator: (newVal) =>
                        newVal == null ? ' * required' : null,
                    value: SelectRank.mySelection,
                  ),
                ),
              )
            : Container(),
      ],
    );
  }
}
