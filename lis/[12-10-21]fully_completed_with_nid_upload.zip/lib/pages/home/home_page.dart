import 'package:age/age.dart';
import 'package:ati_lis/config/fcm_utils.dart';
import 'package:ati_lis/custom/notification_icon.dart';
import 'package:ati_lis/custom/timeline_widget.dart';
import 'package:ati_lis/model/report_model.dart';
import 'package:ati_lis/services/db/db_provider.dart';
import 'package:ati_lis/services/report_service.dart';
import 'package:firebase_messaging/firebase_messaging.dart';
import 'package:flutter/material.dart';
import 'package:ati_lis/config/common_const.dart';
import 'package:ati_lis/custom/drawer/drawer_menu.dart';
import 'package:flutter/services.dart';
import 'package:flutter_local_notifications/flutter_local_notifications.dart';
import 'patient_report_view/patient_view.dart';
import 'dart:ui';
import 'dart:developer';

import 'report_view_page.dart';

class MyHomePage extends StatefulWidget {
  @override
  MyHomePageState createState() => MyHomePageState();
}

class MyHomePageState extends State<MyHomePage> {
  Report patientInfo = new Report();
  var isLoading = true;
  String title = 'Title info';
  DBProvider dbProvider = DBProvider();

  String getNotificationDate() {
    DateTime now = DateTime.now();
    String notificationDate = now.day.toString() +
        "-" +
        now.month.toString() +
        "-" +
        now.year.toString() +
        " " +
        now.hour.toString() +
        ":" +
        now.minute.toString();
    return notificationDate;
  }

  //works when app is in foreground mode
  foregroundMode() {
    FirebaseMessaging.onMessage.listen((RemoteMessage message) {
      RemoteNotification notification = message.notification;
      AndroidNotification android = message.notification?.android;
      if (notification != null && android != null) {
        log(notification.title);
        log(message.from);
        setState(() {
          title = notification.title;
        });
        dbProvider.addToNotificationData(
            notification.title, notification.body, getNotificationDate());
        flutterLocalNotificationsPlugin.show(
            notification.hashCode,
            notification.title,
            notification.body,
            NotificationDetails(
              android: AndroidNotificationDetails(
                channel.id,
                channel.name,
                channel.description,
                color: Colors.blue,
                playSound: true,
                icon: '@mipmap/ic_launcher',
              ),
            ));
      }
    });
  }

  //works when app is in background mode and user taps on the notification
  backgroundMode() {
    FirebaseMessaging.onMessageOpenedApp.listen((RemoteMessage message) {
      print('A new onMessageOpenedApp event was published!');
      RemoteNotification notification = message.notification;
      AndroidNotification android = message.notification?.android;
      if (notification != null && android != null) {
        log(notification.body);
        setState(() {
          title = notification.title;
        });
        dbProvider.addToNotificationData(
            notification.title, notification.body, getNotificationDate());
        showDialog(
            context: context,
            builder: (_) {
              return AlertDialog(
                title: Text(notification.title),
                content: SingleChildScrollView(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [Text(notification.body)],
                  ),
                ),
              );
            });
      }
    });
  }

  // getFirebaseToken() async {
  //   String token = await FirebaseMessaging.instance.getToken();
  //   log('Token: $token');
  // }

  @override
  void initState() {
    PatientService().fetchPatientInfo().then((data) {
      setState(() {
        patientInfo = data;
        isLoading = false;
      });
    });
    foregroundMode();
    backgroundMode();
    DBProvider().initDB();
    // getFirebaseToken();
    super.initState();
  }

  String calculateAge(String dateOfBirth) {
    DateTime birthday = DateTime.parse(dateOfBirth.split('/').reversed.join());
    DateTime today = DateTime.now(); //2020/1/24

    AgeDuration age;

    // Find out your age
    age = Age.dateDifference(
        fromDate: birthday, toDate: today, includeToDate: false);

    return age.years.toString();
  }

  @override
  Widget build(BuildContext context) {
    var data = patientInfo.pReturnmsg0;
    return Scaffold(
      appBar: getAppBar(),
      body: isLoading
          ? Center(
              child: CircularProgressIndicator(
                valueColor: AlwaysStoppedAnimation<Color>(cViolet),
              ),
            )
          : patientInfo.pReturnmsg0.isEmpty
              ? Center(
                  child: Text('No data found!'),
                )
              : Column(
                  children: [
                    SizedBox(height: 10),
                    Container(
                      height: 50,
                      child: Row(
                        children: [
                          SizedBox(
                            width: 13.5,
                          ),
                          CustomTimeLine(
                            height: 14,
                            lineColor: cViolet,
                            circleColor: cViolet,
                            enableImage: true,
                            isImageFromApi: data[0].photoLoca.toString() == ''
                                ? false
                                : true,
                            imageUrl: data[0].photoLoca.toString() == ''
                                ? data[0].gender.toString().toLowerCase() ==
                                        'male'
                                    ? 'assets/images/male.png'
                                    : 'assets/images/female.png'
                                : data[0].photoLoca.toString(),
                          ),
                          SizedBox(
                            width: 18.0,
                          ),
                          Container(
                            width: MediaQuery.of(context).size.width - 68,
                            child: Column(
                              mainAxisAlignment: MainAxisAlignment.start,
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Text(
                                  data[0].patientNm.toString(),
                                  overflow: TextOverflow.ellipsis,
                                  maxLines: 2,
                                  style: TextStyle(
                                      color: cViolet,
                                      fontSize: 20,
                                      fontWeight: FontWeight.w500),
                                ),
                                Text(
                                  '${data[0].patientNo.toString()} / ${calculateAge(data[0].dtofBirth.toString())} yrs',
                                  style: TextStyle(
                                      color: cViolet,
                                      fontSize: 16,
                                      fontWeight: FontWeight.w400),
                                ),
                              ],
                            ),
                          ),
                        ],
                      ),
                    ),
                    Expanded(
                      child: ListView.builder(
                          itemCount: data.length,
                          itemBuilder: (context, index) {
                            return GestureDetector(
                              onTap: () {
                                Navigator.push(
                                  context,
                                  MaterialPageRoute(
                                    builder: (context) => ReportViewPage(
                                      indexNo: index,
                                      patientInfo: patientInfo,
                                      patientName: data[0].patientNm.toString(),
                                      patientNo: data[0].patientNo.toString(),
                                      gender: data[0]
                                          .gender
                                          .toString()
                                          .toLowerCase(),
                                      imageUrl: data[0].photoLoca.toString(),
                                    ),
                                  ),
                                );
                              },
                              child: PatientView(
                                patientName: data[index].patientNm.toString(),
                                reqNo: data[index].voucherId.toString(),
                                // gender: data[index].gender.toString(),
                                visitDate: data[index].voucherDt.toString(),
                                totalReport: data[index].totalReport.toString(),
                                referredBy: data[index].refBy.toString(),
                                pendingReport:
                                    data[index].pendingReport.toString(),
                                collectedSample:
                                    data[index].collectedSample.toString(),
                                totalInstruction:
                                    data[index].totalInstruction.toString(),
                                totalSample: data[index].totalSample.toString(),
                                consultationNo:
                                    data[index].consultNo.toString(),
                                admissionNo: data[index].admsionNo.toString(),
                                index: index,
                                listLength: data.length,
                              ),
                            );
                          }),
                    ),
                  ],
                ),
      drawer: DrawerMenu(),
    );
  }

  AppBar getAppBar() {
    return AppBar(
      brightness: Brightness.dark,
      backgroundColor: cViolet,
      centerTitle: true,
      title: Text(
        'ATI MediTop',
        //style: TextStyle(fontSize: 19),
      ),
      actions: [
        // IconButton(
        //   icon: Icon(Icons.notifications),
        //   onPressed: () {
        //     showDialog(
        //       context: context,
        //       useRootNavigator: false,
        //       builder: (context) => NotificationDialogue(),
        //     );
        //   },
        // ),
        NamedIcon(
          text: 'Inbox',
          iconData: Icons.notifications,
        ),
      ],
    );
  }
}
