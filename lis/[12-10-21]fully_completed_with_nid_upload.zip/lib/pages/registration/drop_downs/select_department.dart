// import 'package:flutter/material.dart';

// class SelectDepartment extends StatefulWidget {
//   static String dropdownValue;
//   @override
//   _SelectDepartmentState createState() => _SelectDepartmentState();
// }

// class _SelectDepartmentState extends State<SelectDepartment> {
//   List<String> listValue = [
//     'Bangladesh Army',
//     'Bangladesh Air Force',
//     'Bangladesh Navy',
//   ];
//   @override
//   Widget build(BuildContext context) {
//     return Padding(
//       padding: const EdgeInsets.only(top: 8.0),
//       child: Container(
//         decoration: BoxDecoration(
//             border: Border.all(width: 1.5, color: Colors.black),
//             borderRadius: BorderRadius.all(Radius.circular(5))),
//         child: DropdownButtonFormField<String>(
//           isExpanded: true,
//           hint: Padding(
//             padding: const EdgeInsets.only(left: 8.0),
//             child: Text("Select Department"),
//           ),
//           validator: (newVal) => newVal == null ? ' * required' : null,
//           value: SelectDepartment.dropdownValue,
//           icon: Icon(Icons.arrow_drop_down),
//           // iconSize: 30, //this inicrease the size
//           // elevation: 16,
//           style: TextStyle(color: Colors.black),
//           onChanged: (String newValue) {
//             setState(() {
//               SelectDepartment.dropdownValue = newValue;
//             });
//             print(SelectDepartment.dropdownValue);
//           },
//           items: listValue.map<DropdownMenuItem<String>>((String value) {
//             return DropdownMenuItem<String>(
//               value: value,
//               child: Padding(
//                 padding: const EdgeInsets.only(left: 8.0),
//                 child: Text(value),
//               ),
//             );
//           }).toList(),
//         ),
//       ),
//     );
//   }
// }
