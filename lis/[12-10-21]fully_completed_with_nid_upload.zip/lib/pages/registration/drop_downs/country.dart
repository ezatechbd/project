import 'package:flutter/material.dart';

class SelectCountry extends StatefulWidget {
  final Map projectListdropdown;
  static Map mySelection;
  const SelectCountry({
    Key key,
    @required this.projectListdropdown,
  }) : super(key: key);

  @override
  _SelectCountryState createState() => _SelectCountryState();
}

class _SelectCountryState extends State<SelectCountry> {
  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.only(top: 12.0),
      child: Container(
        decoration: BoxDecoration(
            border: Border.all(width: 1.5, color: Colors.black),
            borderRadius: BorderRadius.all(Radius.circular(5))),
        child: DropdownButtonFormField(
          // underline: SizedBox(),
          // searchHint: 'Select Project',
          hint: Padding(
            padding: const EdgeInsets.only(left: 8.0),
            child: Text("Select Your Nationality"),
          ),
          isExpanded: true,
          items: widget.projectListdropdown['country']
              .map<DropdownMenuItem<Map>>((item) {
            return new DropdownMenuItem<Map>(
              value: item,
              child: Padding(
                padding: const EdgeInsets.only(left: 8.0),
                child: new Text(
                  item["r_name"].toString(),
                ),
              ),
            );
          }).toList(),
          onChanged: (newVal) {
            setState(() {
              SelectCountry.mySelection = newVal == null ? {} : newVal;
              print(
                SelectCountry.mySelection.toString(),
                // SelectCountry.mySelection['PROJT_NAME']
                //     .toString(),
              );
            });
          },
          validator: (newVal) => newVal == null ? ' * required' : null,
          value: SelectCountry.mySelection,
        ),
      ),
    );
  }
}
