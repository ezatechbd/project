import 'package:flutter/material.dart';

class SelectBirthMonth extends StatefulWidget {
  static String dropdownValue;
  @override
  _SelectBirthMonthState createState() => _SelectBirthMonthState();
}

class _SelectBirthMonthState extends State<SelectBirthMonth> {
  List<Month> allMonth = [
    Month(month: 'Jan', id: '01'),
    Month(month: 'Feb', id: '02'),
    Month(month: 'Mar', id: '03'),
    Month(month: 'Apr', id: '04'),
    Month(month: 'May', id: '05'),
    Month(month: 'Jun', id: '06'),
    Month(month: 'Jul', id: '07'),
    Month(month: 'Aug', id: '08'),
    Month(month: 'Sep', id: '09'),
    Month(month: 'Oct', id: '10'),
    Month(month: 'Nov', id: '11'),
    Month(month: 'Dec', id: '12'),
  ];
  @override
  Widget build(BuildContext context) {
    return Container(
        width: 90,
        decoration: BoxDecoration(
            border: Border.all(width: 1.5, color: Colors.black),
            borderRadius: BorderRadius.all(Radius.circular(5))),
        child: DropdownButtonFormField<String>(
          isExpanded: true,
          hint: Padding(
            padding: const EdgeInsets.only(left: 8.0),
            child: Text("Month"),
          ),
          value: SelectBirthMonth.dropdownValue,
          icon: Icon(Icons.arrow_drop_down),
          // iconSize: 30, //this inicrease the size
          // elevation: 16,
          style: TextStyle(color: Colors.black),
          validator: (newVal) => newVal == null ? ' * required' : null,
          onChanged: (String newValue) {
            setState(() {
              SelectBirthMonth.dropdownValue = newValue;
            });
            print(SelectBirthMonth.dropdownValue);
          },
          items: allMonth.map((value) {
            return DropdownMenuItem<String>(
              value: value.id,
              child: Padding(
                padding: const EdgeInsets.only(left: 8.0),
                child: Text(value.month),
              ),
            );
          }).toList(),
        ));
  }
}

class Month {
  String month;
  String id;

  Month({this.month, this.id});
}
