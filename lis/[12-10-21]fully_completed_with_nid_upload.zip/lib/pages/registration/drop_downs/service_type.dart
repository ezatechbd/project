import 'package:flutter/material.dart';

class SelectServiceType extends StatefulWidget {
  final Map projectListdropdown;
  static Map mySelection;
  const SelectServiceType({
    Key key,
    @required this.projectListdropdown,
  }) : super(key: key);

  @override
  _SelectServiceTypeState createState() => _SelectServiceTypeState();
}

class _SelectServiceTypeState extends State<SelectServiceType> {
  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.only(top: 12.0),
      child: Container(
        decoration: BoxDecoration(
            border: Border.all(width: 1.5, color: Colors.black),
            borderRadius: BorderRadius.all(Radius.circular(5))),
        child: DropdownButtonFormField(
          // underline: SizedBox(),
          // searchHint: 'Select Project',
          hint: Padding(
            padding: const EdgeInsets.only(left: 8.0),
            child: Text("Select Service Type"),
          ),
          isExpanded: true,
          items: widget.projectListdropdown['servicetype']
              .map<DropdownMenuItem<Map>>((item) {
            return new DropdownMenuItem<Map>(
              value: item,
              child: Padding(
                padding: const EdgeInsets.only(left: 8.0),
                child: new Text(
                  item["r_name"].toString(),
                ),
              ),
            );
          }).toList(),
          onChanged: (newVal) {
            setState(() {
              SelectServiceType.mySelection = newVal == null ? {} : newVal;
              print(
                SelectServiceType.mySelection.toString(),
                // SelectServiceType.mySelection['PROJT_NAME']
                //     .toString(),
              );
            });
          },
          validator: (newVal) => newVal == null ? ' * required' : null,
          value: SelectServiceType.mySelection,
        ),
      ),
    );
  }
}
