import 'dart:developer';
import 'dart:io';
import 'package:ati_lis/services/upload_image_service.dart';
import 'package:firebase_ml_vision/firebase_ml_vision.dart';
import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import 'package:http/http.dart' as http;
// import 'package:http_parser/http_parser.dart';

final nameFromOcr = ValueNotifier<String>('Hi');
final nidFromOcr = ValueNotifier<String>('Hi');
final dobFromOcr = ValueNotifier<String>('Hi');

class PickNidImages extends StatefulWidget {
  final String uploadUrl;

  const PickNidImages({Key key, @required this.uploadUrl}) : super(key: key);
  // static String base64Image = '';
  // static List base64ImageList = [];
  @override
  _PickNidImagesState createState() => _PickNidImagesState();
}

class _PickNidImagesState extends State<PickNidImages> {
  List<Object> images = [];
  Future<PickedFile> _imageFile;
  final picker = ImagePicker();

  String ocrText = '';

  Future scanText(File imageFile) async {
    showDialog(
        context: context,
        builder: (context) {
          return Center(
            child: CircularProgressIndicator(),
          );
        });
    final FirebaseVisionImage visionImage =
        FirebaseVisionImage.fromFile(imageFile);
    final TextRecognizer textRecognizer =
        FirebaseVision.instance.textRecognizer();
    final VisionText visionText =
        await textRecognizer.processImage(visionImage);

    for (TextBlock block in visionText.blocks) {
      for (TextLine line in block.lines) {
        ocrText += line.text + '@';
      }
    }

    Navigator.of(context).pop();
    // log(ocrText);
    log('Scanned Text to LowerCase: {${ocrText.toLowerCase()}}');

    log('Name: ${getText('name@', '@')}');
    log('NID No: ${getText('nid no@', '@')}');
    log('Date of Birth: ${getText('@date of birth', '@')}');
    nameFromOcr.value = getText('name@', '@').toUpperCase();
    nidFromOcr.value = getText('nid no@', '@').toUpperCase();
    dobFromOcr.value = getText('@date of birth', '@').trimLeft().toUpperCase();
    // Navigator.of(context)
    //     .push(MaterialPageRoute(builder: (context) => Details(ocrText)));
  }

  String getText(String start, String end) {
    String str = ocrText.toLowerCase();
    final startIndex = str.indexOf(start);
    final endIndex = str.indexOf(end, startIndex + start.length);
    String textFromOcr = str.substring(startIndex + start.length, endIndex);
    return textFromOcr;
  }

  Future _onAddImageClick(int index, int type) async {
    if (images != null)
      setState(() {
        // ignore: deprecated_member_use
        _imageFile = picker.getImage(
          source: type == 1 ? ImageSource.camera : ImageSource.gallery,
          imageQuality: 50,
        );
        getFileImage(index);
      });
  }

  void getFileImage(int index) async {
    _imageFile.then((file) async {
      //SharedPreferences prefs = await SharedPreferences.getInstance();
      //var userCode = prefs.getString('userCode');
      setState(() {
        ImageUploadModel imageUpload = new ImageUploadModel();
        imageUpload.imageFile = File(file.path);
        // List<int> imageBytes = File(file.path).readAsBytesSync();
        // PickNidImages.base64Image = base64Encode(imageBytes);
        // print(PickNidImages.base64Image);
        images.replaceRange(index, index + 1, [imageUpload]);
        scanText(File(file.path));
        ImageUploadService(isNidSelected: true)
            .uploadImage(File(file.path), context, widget.uploadUrl);
        //PickNidImages.base64ImageList = List();
        // PickNidImages.base64ImageList.add(base64Image);
        //log('Image Test $base64ImageList');

        //post image with additional informations
        // sendImage(
        //     base64Image.toString(), //post image to server
        //     SelectClient.mySelection['CLIENTS_ID'].toString(),
        //     SelectProject.mySelection['PROJECT_ID'].toString(),
        //     userCode.toString());
      });
    });
  }

  @override
  void initState() {
    super.initState();
    setState(() {
      images.add("Add Image");
      // images.add("Add Image");
      // images.add("Add Image");
      // images.add("Add Image");
      // images.add("Add Image");
      // images.add("Add Image");
    });
  }

  @override
  Widget build(BuildContext context) {
    // var width = MediaQuery.of(context).size.width;
    return Container(
      width: 180,
      height: 170,
      child: GridView.count(
        shrinkWrap: true,
        physics: const NeverScrollableScrollPhysics(),
        crossAxisCount: 1,
        childAspectRatio: 1.4,
        children: List.generate(images.length, (index) {
          if (images[index] is ImageUploadModel) {
            ImageUploadModel uploadModel = images[index];
            // //base64 image
            // List<int> imageBytes =
            //     uploadModel.imageFile.readAsBytesSync();
            // PickNidImages.base64Image = base64Encode(
            //     imageBytes); //'base64Image' holds the base64 image string
            return Container(
              decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  border: Border.all(width: 1, color: Colors.transparent)),
              clipBehavior: Clip.antiAlias,
              child: Stack(
                children: <Widget>[
                  Image.file(
                    uploadModel.imageFile,
                    fit: BoxFit.cover,
                    width: 300,
                    height: 300,
                  ),
                  Positioned(
                    right: 45,
                    top: 15,
                    child: InkWell(
                      child: Icon(
                        Icons.remove_circle,
                        size: 40,
                        color: Colors.red,
                      ),
                      onTap: () {
                        // PickNidImages.base64Image = '';
                        ocrText = '';
                        setState(() {
                          images.replaceRange(index, index + 1, ['Add Image']);
                        });
                      },
                    ),
                  ),
                  // ignore: deprecated_member_use
                  // RaisedButton(
                  //   child: Text('imgInfo'),
                  //   onPressed: () {
                  //     // String start = "@Date of Birth";
                  //     // String end = "@";

                  //     String getText(String start, String end) {
                  //       String str = ocrText;
                  //       final startIndex = str.indexOf(start);
                  //       final endIndex =
                  //           str.indexOf(end, startIndex + start.length);
                  //       String textFromOcr =
                  //           str.substring(startIndex + start.length, endIndex);
                  //       return textFromOcr;
                  //     }

                  //     log('Name: ${getText('Name@', '@')}');
                  //     log('NID No: ${getText('NID No@', '@')}');
                  //     log('Date of Birth: ${getText('@Date of Birth', '@')}');
                  //     showDialog(
                  //         context: context,
                  //         builder: (context) {
                  //           return AlertDialog(
                  //             content: Container(
                  //               constraints: BoxConstraints(maxHeight: 100.0),
                  //               child: Column(
                  //                 crossAxisAlignment: CrossAxisAlignment.start,
                  //                 children: [
                  //                   Text('Name: ${getText('Name@', '@')}'),
                  //                   Text('NID No: ${getText('NID No@', '@')}'),
                  //                   Text(
                  //                       'Date of Birth: ${getText('@Date of Birth', '@')}'),
                  //                 ],
                  //               ),
                  //             ),
                  //           );
                  //         });
                  //     // print(
                  //     //     "${uploadModel.imageFile.lengthSync() / 1024} KB"); //print image size in kb
                  //     // print(uploadModel
                  //     //     .imageFile.path); //print image path
                  //     // // log(PickNidImages.base64Image);
                  //     // uploadImage(File(uploadModel.imageFile.path));
                  //   },
                  // ),
                ],
              ),
            );
          } else {
            return Container(
              decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  border: Border.all(width: 1, color: Colors.grey)),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.center,
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  IconButton(
                    icon: Icon(Icons.camera_alt),
                    onPressed: () {
                      showModalBottomSheet(
                        context: context,
                        builder: (BuildContext context) {
                          return SafeArea(
                            child: Container(
                              child: new Wrap(
                                children: <Widget>[
                                  new ListTile(
                                    leading: new Icon(Icons.photo_camera),
                                    title: new Text('Camera'),
                                    onTap: () {
                                      _onAddImageClick(index, 1);
                                      Navigator.of(context).pop();
                                    },
                                  ),
                                  new ListTile(
                                      leading: new Icon(Icons.photo_library),
                                      title: new Text('Gallery'),
                                      onTap: () {
                                        _onAddImageClick(index, 2);
                                        Navigator.of(context).pop();
                                      }),
                                ],
                              ),
                            ),
                          );
                        },
                      );
                    },
                  ),
                  Container(
                      height: 30,
                      width: 102,
                      child: Text('Upload your NID card'))
                ],
              ),
            );
          }
        }),
      ),
    );
  }
}

class ImageUploadModel {
  File imageFile;

  ImageUploadModel({
    this.imageFile,
  });
}

// uploadImage(File file) async {
//   print('vndf');
//   var postUri =
//       Uri.parse("http://192.168.0.29:9050/tourplan_ws/file/uploadFile");
//   var request = new http.MultipartRequest("POST", postUri);
//   // Map<String, String> headers = {'Content-Type': 'multipart/form-data'};
//   // request.headers["Content-Type"] = 'multipart/form-data';
//   // request.fields['user'] = 'blah';
//   request.files.add(
//     new http.MultipartFile.fromBytes(
//       'file',
//       await File.fromUri(Uri.parse(file.path)).readAsBytes(),
//       // contentType: MediaType("image", "${file.path.split(".").last}"),
//     ),
//   );

//   request.send().then((response) {
//     print(response.statusCode);
//     if (response.statusCode == 200) {
//       print("Uploaded!");
//     } else {
//       print("Failed!");
//     }
//   });
// }

uploadImage(File file) async {
  var request = http.MultipartRequest('POST',
      Uri.parse('http://gpst.billingdil.com:8088/tourplan_ws/file/uploadFile'));
  request.files.add(await http.MultipartFile.fromPath('file', file.path));

  http.StreamedResponse response = await request.send();

  if (response.statusCode == 200) {
    print(await response.stream.bytesToString());
  } else {
    print(response.reasonPhrase);
  }
}
