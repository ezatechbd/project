import 'package:ati_lis/custom/timeline_widget.dart';
import 'package:flutter/material.dart';
import 'dart:ui';
import 'package:ati_lis/config/common_const.dart';
import 'package:ati_lis/custom/user_info.dart';
import 'package:ati_lis/pages/profile/flip_card/flip_card.dart';
// import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:shared_preferences/shared_preferences.dart';

class UserProfile extends StatefulWidget {
  @override
  _UserProfileState createState() => _UserProfileState();
}

class _UserProfileState extends State<UserProfile> {
  TextEditingController _nameController = TextEditingController();
  bool isEditable = false;
  String profileName;
  String profileWorkUnit;
  String profileDob;
  String profileBloodGroup;
  String profilePhone;
  String profileEmail;

  @override
  void initState() {
    getProfileValuesFromSP();
    super.initState();
    _nameController.text =
        "MD. Enamul Haque"; // Setting the initial value for the field.
  }

  getProfileValuesFromSP() async {
    SharedPreferences prefs = await SharedPreferences.getInstance();
    setState(() {
      profileName = prefs.getString('profile_name');
      profileWorkUnit = prefs.getString('profile_work_unit');
      profileDob = prefs.getString('profile_dob').substring(0, 10);
      profileBloodGroup = prefs.getString('profile_blood_group');
      profilePhone = prefs.getString('profile_phone');
      profileEmail = prefs.getString('profile_email');
    });
  }

  @override
  Widget build(BuildContext context) {
    double statusBarHeight = MediaQuery.of(context).padding.top;

    return Scaffold(
      resizeToAvoidBottomInset: true,
      body: Container(
        padding: EdgeInsets.only(
          top: statusBarHeight,
          //left: 20,
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: <Widget>[
                IconButton(
                    icon: Icon(Icons.arrow_back),
                    onPressed: () {
                      Navigator.pop(context);
                    }),
                Text(
                  'Profile',
                  style: TextStyle(
                    fontSize: 23,
                    fontWeight: FontWeight.bold,
                    color: cViolet,
                  ),
                ),
              ],
            ),
            FlipCard(),
            // SizedBox(
            //   height: 15,
            // ),
            Flexible(
              child: Container(
                padding: EdgeInsets.only(left: 10),
                child: SingleChildScrollView(
                  child: Column(
                    children: [
                      Row(
                        children: [
                          CustomTimeLine(height: 50),
                          SizedBox(
                            width: 5.0,
                          ),
                          Expanded(
                              flex: 15,
                              child: !isEditable
                                  ? Column(
                                      crossAxisAlignment:
                                          CrossAxisAlignment.start,
                                      children: [
                                        Text(
                                          'Name',
                                          style: TextStyle(
                                            color: Colors.green,
                                            fontSize: 16,
                                            fontWeight: FontWeight.bold,
                                          ),
                                        ),
                                        Text(
                                          // _nameController.text,
                                          profileName.toString(),
                                          style: TextStyle(fontSize: 18),
                                        ),
                                        Divider(
                                          thickness: 1.0,
                                        ),
                                        SizedBox(
                                          height: 8,
                                        ),
                                      ],
                                    )
                                  : TextFormField(
                                      controller: _nameController,
                                      textInputAction: TextInputAction.done,
                                      onFieldSubmitted: (value) {
                                        print('Name Changed!');
                                        setState(() {
                                          isEditable = false;
                                          _nameController.text = value;
                                        });
                                      })),
                          // IconButton(
                          //     icon: Icon(
                          //       FontAwesomeIcons.edit,
                          //       size: 15,
                          //     ),
                          //     onPressed: () {
                          //       setState(() {
                          //         isEditable = true;
                          //       });
                          //     })
                        ],
                      ),
                      UserInfo(
                        title: 'Force Name',
                        info: 'Bangladesh Army',
                      ),
                      UserInfo(
                        title: 'Rank',
                        info: 'Major General',
                      ),
                      UserInfo(
                        title: 'Working Unit',
                        info: profileWorkUnit.toString(),
                      ),
                      UserInfo(
                        title: 'Nationality',
                        info: 'Bangladeshi',
                      ),
                      UserInfo(
                        title: 'Date of Birth',
                        info: profileDob.toString(),
                      ),
                      UserInfo(
                        title: 'Religion',
                        info: 'Islam',
                      ),
                      UserInfo(
                        title: 'Gender',
                        info: 'Male',
                      ),
                      UserInfo(
                        title: 'Blood Group',
                        info: profileBloodGroup.toString(),
                      ),
                      UserInfo(
                        title: 'Maritial Status',
                        info: 'Single',
                      ),
                      UserInfo(
                        title: 'Phone',
                        info: profilePhone.toString(),
                      ),
                      UserInfo(
                        title: 'Email',
                        info: profileEmail.toString(),
                      ),
                      UserInfo(
                        title: 'National ID',
                        info: '5058437347',
                      ),
                      UserInfo(
                        title: 'Present Address',
                        info: '334/2, West Rampura, Dhaka-1219',
                      ),
                      UserInfo(
                        title: 'Patient Status',
                        info: 'Registered',
                      ),
                    ],
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
