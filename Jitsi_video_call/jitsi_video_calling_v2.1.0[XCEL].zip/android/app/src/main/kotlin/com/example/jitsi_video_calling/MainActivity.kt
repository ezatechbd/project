package com.example.jitsi_video_calling

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
